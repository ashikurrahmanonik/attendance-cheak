package __PKG__;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * In-app updater: downloads the new APK into the app cache with progress events
 * and opens Android's package installer. No browser involved.
 */
@CapacitorPlugin(name = "ApkInstaller")
public class ApkInstallerPlugin extends Plugin {
    private volatile boolean cancelled = false;
    private volatile boolean busy = false;

    private boolean allowed() {
        return Build.VERSION.SDK_INT < 26 || getContext().getPackageManager().canRequestPackageInstalls();
    }

    private File updateDir() {
        return new File(getContext().getCacheDir(), "update");
    }

    @PluginMethod
    public void canInstall(PluginCall call) {
        JSObject r = new JSObject();
        r.put("allowed", allowed());
        call.resolve(r);
    }

    /** Opens "Install unknown apps" for this app. */
    @PluginMethod
    public void openSettings(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("Cannot open settings");
        }
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        cancelled = true;
        call.resolve();
    }

    @PluginMethod
    public void download(final PluginCall call) {
        final String link = call.getString("url");
        if (link == null || !link.startsWith("https://")) {
            call.reject("Invalid download link");
            return;
        }
        if (busy) {
            call.reject("A download is already running");
            return;
        }
        busy = true;
        cancelled = false;
        new Thread(new Runnable() {
            @Override
            public void run() {
                doDownload(call, link);
            }
        }).start();
    }

    private HttpURLConnection open(String link) throws Exception {
        String current = link;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(current).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", "AttendanceApp-Updater");
            c.setRequestProperty("Accept", "application/octet-stream");
            int code = c.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String next = c.getHeaderField("Location");
                c.disconnect();
                if (next == null || !next.startsWith("https://")) throw new Exception("Bad redirect");
                current = next;
                continue;
            }
            if (code != 200) {
                c.disconnect();
                throw new Exception("Server answered " + code);
            }
            return c;
        }
        throw new Exception("Too many redirects");
    }

    private void doDownload(PluginCall call, String link) {
        HttpURLConnection c = null;
        InputStream in = null;
        OutputStream out = null;
        File dest = null;
        try {
            File dir = updateDir();
            if (!dir.exists()) dir.mkdirs();
            File[] olds = dir.listFiles();
            if (olds != null) {
                for (File f : olds) f.delete();
            }
            dest = new File(dir, "update.apk");
            c = open(link);
            long total = c.getContentLengthLong();
            in = c.getInputStream();
            out = new FileOutputStream(dest);
            byte[] buf = new byte[32768];
            long done = 0;
            long last = 0;
            int n;
            while ((n = in.read(buf)) != -1) {
                if (cancelled) throw new Exception("cancelled");
                out.write(buf, 0, n);
                done += n;
                long now = System.currentTimeMillis();
                if (now - last > 150) {
                    last = now;
                    JSObject p = new JSObject();
                    p.put("loaded", done);
                    p.put("total", total);
                    notifyListeners("progress", p);
                }
            }
            out.flush();
            out.close();
            out = null;
            if (total > 0 && done != total) throw new Exception("Download incomplete, try again");
            JSObject r = new JSObject();
            r.put("path", dest.getAbsolutePath());
            r.put("size", done);
            call.resolve(r);
        } catch (Exception e) {
            if (dest != null) dest.delete();
            call.reject(e.getMessage() == null ? "Download failed" : e.getMessage());
        } finally {
            try { if (out != null) out.close(); } catch (Exception ignore) { }
            try { if (in != null) in.close(); } catch (Exception ignore) { }
            if (c != null) c.disconnect();
            busy = false;
        }
    }

    @PluginMethod
    public void install(PluginCall call) {
        try {
            String path = call.getString("path");
            if (path == null) {
                call.reject("No file");
                return;
            }
            File f = new File(path);
            if (!f.exists() || !f.getCanonicalPath().startsWith(updateDir().getCanonicalPath())) {
                call.reject("Update file not found");
                return;
            }
            if (!allowed()) {
                call.reject("NOT_ALLOWED");
                return;
            }
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage() == null ? "Cannot start install" : e.getMessage());
        }
    }
}
