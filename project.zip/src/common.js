import {initializeApp} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {getFirestore,collection,doc,getDoc,getDocs,setDoc,deleteDoc,addDoc,query,where,orderBy,limit,onSnapshot} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
export {collection,doc,getDoc,getDocs,setDoc,deleteDoc,addDoc,query,where,orderBy,limit,onSnapshot};
export const VERSION="0.0.0",REPO="OWNER/REPO";
export const fapp=initializeApp({apiKey:"AIzaSyCTLEMCGWzfW7YrOUgs_8dpVXvwURCvTUU",authDomain:"attendance-1a201.firebaseapp.com",projectId:"attendance-1a201",storageBucket:"attendance-1a201.firebasestorage.app",messagingSenderId:"570816599324",appId:"1:570816599324:web:d1295957aedf3a6c20d6d9"});
export const db=getFirestore(fapp);
export const $=s=>document.querySelector(s);
export const esc=s=>String(s??'').replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
export const today=()=>new Date().toLocaleDateString('en-CA');
export const hm=()=>new Date().toTimeString().slice(0,5);
export const norm=p=>String(p||'').replace(/\D/g,'').slice(-10);
export const isApp=()=>!!window.Capacitor?.isNativePlatform?.();
export const inWin=(b,n=hm())=>b.start<=b.end?(n>=b.start&&n<b.end):(n>=b.start||n<b.end);
export const toMin=t=>+t.slice(0,2)*60+ +t.slice(3,5);
export const isLate=(b,n=hm())=>{let d=toMin(n)-toMin(b.start);if(d<0)d+=1440;return d>(b.grace??15)};
let _org;
export async function getOrg(force){
  if(_org&&!force)return _org;
  let d={};try{d=(await getDoc(doc(db,'settings','org'))).data()||{}}catch{}
  return _org={name:d.name||'Sabuj Computer Training Center',logo:d.logo||'logo.png',fields:d.fields||[],grace:d.grace??15,admin:d.admin||''};
}
export async function saveFile(name,dataUrl){
  const Pl=window.Capacitor?.Plugins;
  if(isApp()&&Pl?.Filesystem&&Pl?.Share){
    try{const f=await Pl.Filesystem.writeFile({path:name,data:dataUrl.split(',')[1],directory:'CACHE'});await Pl.Share.share({title:name,files:[f.uri]})}
    catch(e){if(!/cancel/i.test(e.message||''))toast('Could not save: '+e.message,'bad')}
    return;
  }
  const a=document.createElement('a');a.href=dataUrl;a.download=name;document.body.append(a);a.click();a.remove();
}
const P={scan:'<path d="M4 8V5a1 1 0 011-1h3M16 4h3a1 1 0 011 1v3M20 16v3a1 1 0 01-1 1h-3M8 20H5a1 1 0 01-1-1v-3M4 12h16"/>',users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 3-6 6.5-6s6.5 2.4 6.5 6M16 4.8a3.5 3.5 0 010 6.4M18 14.2c2.2.7 3.5 2.6 3.5 5.8"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',check:'<circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/>',bell:'<path d="M6 17v-6a6 6 0 1112 0v6l1.5 2h-15zM10 21h4"/>',gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9L7 7M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1"/>',home:'<path d="M4 11l8-7 8 7v9H4zM10 20v-6h4v6"/>',logout:'<path d="M9 4H5v16h4M16 8l4 4-4 4M20 12H9"/>',plus:'<path d="M12 5v14M5 12h14"/>',trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',qr:'<rect x="4" y="4" width="6" height="6"/><rect x="14" y="4" width="6" height="6"/><rect x="4" y="14" width="6" height="6"/><path d="M14 14h2v2h-2zM18 18h2v2h-2zM14 18h2M18 14h2"/>',dl:'<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',edit:'<path d="M4 20h4L19 9l-4-4L4 16z"/>',chart:'<path d="M5 20V10M12 20V4M19 20v-7"/>',menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',phone:'<path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z"/>',back:'<path d="M15 5l-7 7 7 7"/>',link:'<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1"/>',file:'<path d="M6 3h8l5 5v13H6zM14 3v5h5M9 13h6M9 17h6"/>',sms:'<path d="M4 5h16v11H9l-5 4z"/>',refresh:'<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',pin:'<path d="M9 4h6l-1 6 3 3H7l3-3zM12 13v8"/>'};
export const I=(n,s=22)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${P[n]}</svg>`;
export const initials=n=>String(n||'?').trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase();
export const avatar=(s,c='')=>s.photo?`<img class="av ${c}" src="${esc(s.photo)}" alt="">`:`<div class="av ${c}">${esc(initials(s.name))}</div>`;
export function toast(m,t=''){const d=document.createElement('div');d.className='toast '+t;d.textContent=m;document.body.append(d);setTimeout(()=>d.remove(),3500)}
export function modal(html){const m=document.createElement('div');m.className='mdl';m.innerHTML=`<div class="sheet">${html}</div>`;m.addEventListener('click',e=>{if(e.target===m)m.remove()});document.body.append(m);return m}
export const ask=(msg,ok='Delete')=>new Promise(r=>{const m=modal(`<p>${esc(msg)}</p><div class="two"><button class="btn ghost" id="n">Cancel</button><button class="btn bad" id="y">${ok}</button></div>`);m.querySelector('#n').onclick=()=>{m.remove();r(false)};m.querySelector('#y').onclick=()=>{m.remove();r(true)};m.addEventListener('click',e=>{if(e.target===m)r(false)})});
function resize(file,max=480){return new Promise((res,rej)=>{const i=new Image(),u=URL.createObjectURL(file);i.onload=()=>{const r=Math.min(1,max/Math.max(i.width,i.height)),c=document.createElement('canvas');c.width=Math.round(i.width*r);c.height=Math.round(i.height*r);c.getContext('2d').drawImage(i,0,0,c.width,c.height);URL.revokeObjectURL(u);c.toBlob(b=>b?res(b):rej(Error('Image error')),'image/jpeg',.82)};i.onerror=()=>rej(Error('This file is not a valid image'));i.src=u})}
async function send(blob,name){
  const c=(await getDoc(doc(db,'settings','cloudinary'))).data();
  if(!c||!c.cloud||!c.preset)throw Error('Add Cloudinary cloud name and preset in Settings first');
  const f=new FormData();f.append('file',blob,name);f.append('upload_preset',c.preset);
  let j;try{j=await (await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(c.cloud)}/auto/upload`,{method:'POST',body:f})).json()}catch{throw Error('No internet connection')}
  if(!j.secure_url)throw Error('Cloudinary: '+(j.error&&j.error.message||'unknown error'));
  return j.secure_url;
}
export const upload=async file=>send(await resize(file),'photo.jpg');
export async function uploadDoc(file){
  if(file.size>10*1024*1024)throw Error(file.name+' is larger than 10 MB');
  return {name:file.name,url:await send(file.type.startsWith('image/')?await resize(file,1600):file,file.name)};
}
export function openUrl(u){const B=window.Capacitor?.Plugins?.Browser;if(isApp()){if(B)B.open({url:u});else location.href=u}else window.open(u,'_blank','noopener')}
const okUrl=u=>/^https?:\/\//i.test(u||'');
export const linkify=t=>esc(t).replace(/https?:\/\/[^\s<]*[^\s<.,;:!?)]/g,u=>`<a data-u="${u}">${u}</a>`);
export function noticeHTML(a){
  const L=(a.links||[]).filter(l=>okUrl(l.url)).map(l=>`<button class="lk" data-u="${esc(l.url)}">${I('link',16)}<span>${esc(l.label||l.url)}</span></button>`).join('');
  const Fs=(a.files||[]).filter(f=>okUrl(f.url)).map(f=>`<button class="lk file" data-u="${esc(f.url)}">${I('file',16)}<span>${esc(f.name)}</span></button>`).join('');
  return `${a.body?`<p style="white-space:pre-wrap">${linkify(a.body)}</p>`:''}${L||Fs?`<div class="lks">${L}${Fs}</div>`:''}`;
}
export const bindLinks=root=>root.addEventListener('click',e=>{const u=e.target.closest('[data-u]');if(u){e.preventDefault();openUrl(u.dataset.u)}});
export async function notify(t,b){try{const L=window.Capacitor?.Plugins?.LocalNotifications;if(L){await L.requestPermissions();await L.schedule({notifications:[{id:Date.now()%2147483647,title:t,body:b}]})}else if('Notification' in window){if(Notification.permission!=='granted')await Notification.requestPermission();if(Notification.permission==='granted')new Notification(t,{body:b})}}catch{}}
export async function checkUpdate(role){try{if(!isApp())return;const r=await (await fetch(`https://api.github.com/repos/${REPO}/releases/latest`)).json();const v=(r.tag_name||'').replace(/^v/,'');const a=(r.assets||[]).find(x=>x.name.startsWith(role));if(v&&a&&v!==VERSION){const d=document.createElement('div');d.className='upd';d.innerHTML=`<span>New version ${esc(v)} available</span><button>Update</button>`;d.querySelector('button').onclick=()=>openUrl(a.browser_download_url);document.body.prepend(d)}}catch{}}
export function applyTheme(){
  const pref=localStorage.theme||'system',dark=pref==='dark'||(pref==='system'&&!matchMedia('(prefers-color-scheme: light)').matches),bg=dark?'#0a1020':'#f4f6fb';
  document.documentElement.dataset.theme=dark?'dark':'light';
  document.querySelector('meta[name=theme-color]')?.setAttribute('content',bg);
  const S=window.Capacitor?.Plugins?.StatusBar;
  if(isApp()&&S){try{S.setBackgroundColor({color:bg});S.setStyle({style:dark?'DARK':'LIGHT'})}catch{}}
}
export const themePicker=()=>`<div class="seg">${['system','light','dark'].map(k=>`<button data-th="${k}" class="${(localStorage.theme||'system')===k?'on':''}">${k[0].toUpperCase()+k.slice(1)}</button>`).join('')}</div>`;
export const bindTheme=root=>root.addEventListener('click',e=>{const b=e.target.closest('[data-th]');if(!b)return;localStorage.theme=b.dataset.th;applyTheme();root.querySelectorAll('[data-th]').forEach(x=>x.classList.toggle('on',x===b))});
export function onBack(back){
  const A=window.Capacitor?.Plugins?.App;if(!isApp()||!A?.addListener)return;
  A.addListener('backButton',()=>{const ms=document.querySelectorAll('.mdl');if(ms.length)return ms[ms.length-1].dispatchEvent(new MouseEvent('click'));if(!back())A.exitApp()});
}
export function css(){
  const s=document.createElement('style');
  s.textContent=`:root{--bg:#0a1020;--card:#121a2d;--line:#222f4a;--tx:#e8eefc;--mut:#8b9bb8;--pri:#3b82f6;--ok:#22c55e;--bad:#ef4444;--inp:#0d1424;--soft:#1a2540;--okbg:#10301f;--okfg:#86efac;--badbg:#3a1620;--badfg:#fca5a5;--warnbg:#3b2a0a;--warnfg:#fcd34d;--avbg:#1c3156;--avfg:#9cc0ff;--hdr:#0a1020ee;--link:#7db0ff;--sh:0 8px 24px #0006}
:root[data-theme=light]{--bg:#f4f6fb;--card:#fff;--line:#e3e8f2;--tx:#0f172a;--mut:#64748b;--pri:#2563eb;--inp:#f6f8fc;--soft:#eaf0fb;--okbg:#dcfce7;--okfg:#166534;--badbg:#fee2e2;--badfg:#991b1b;--warnbg:#fef3c7;--warnfg:#92400e;--avbg:#dbeafe;--avfg:#1e40af;--hdr:#ffffffee;--link:#1d4ed8;--sh:0 6px 20px #1e293b18}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,"Noto Sans Bengali",sans-serif;-webkit-font-smoothing:antialiased}
#app{max-width:640px;margin:auto;min-height:100vh;padding:68px 14px calc(96px + env(safe-area-inset-bottom))}
.hdr{position:fixed;top:0;left:0;right:0;height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;background:var(--hdr);backdrop-filter:blur(10px);border-bottom:1px solid var(--line);z-index:5;font-size:17px}
.nav{position:fixed;bottom:0;left:0;right:0;display:flex;justify-content:center;background:var(--card);border-top:1px solid var(--line);padding-bottom:env(safe-area-inset-bottom);z-index:5}
.nav button{position:relative;flex:1;max-width:110px;background:none;border:0;color:var(--mut);padding:9px 2px;font-size:11px;font-weight:600;display:flex;flex-direction:column;align-items:center;gap:3px}
.nav button.on{color:var(--pri)}
.nav button.has::after{content:attr(data-n);position:absolute;top:3px;left:55%;background:var(--bad);color:#fff;font-size:10px;line-height:1;border-radius:99px;padding:3px 5px}
input,select,textarea{width:100%;padding:12px 13px;margin-top:6px;border-radius:12px;border:1px solid var(--line);background:var(--inp);color:var(--tx);font:inherit;font-size:16px}
input:focus,select:focus,textarea:focus{outline:2px solid var(--pri);outline-offset:-1px}
label{display:block;margin:10px 0;color:var(--mut);font-size:13px;font-weight:600}
label.sw{color:var(--tx);font-size:15px;font-weight:500}.sw input{width:auto;margin:0 8px 0 0;transform:scale(1.2)}
.btn{display:flex;align-items:center;justify-content:center;gap:6px;width:100%;padding:13px;margin:8px 0;border:0;border-radius:12px;background:var(--pri);color:#fff;font-size:15px;font-weight:700;transition:transform .1s}
.btn:active,.row:active{transform:scale(.98)}
.btn.ghost{background:var(--soft);color:var(--tx)}.btn.bad{background:var(--badbg);color:var(--badfg)}.btn.white{background:#fff;color:#14498c}.btn.sm{padding:9px;font-size:13px;margin:0}.btn:disabled{opacity:.55}
.bar{display:flex;gap:8px;align-items:center;margin:6px 0}.bar .btn{width:auto;margin:0;padding:12px 16px}.bar input{margin:0}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:15px;margin:10px 0;box-shadow:var(--sh)}
.ttl{font-weight:700;display:flex;gap:8px;align-items:center;margin-bottom:6px}
.row,.rowh{display:flex;align-items:center;gap:12px}
.row{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:11px 12px;margin:8px 0}
.grow{flex:1;min-width:0}.m{color:var(--mut);font-size:13px;margin:4px 0}.c{text-align:center}
.av{width:42px;height:42px;border-radius:50%;object-fit:cover;background:var(--avbg);color:var(--avfg);display:flex;align-items:center;justify-content:center;font-weight:700;flex:none;margin:auto 0}
.row .av,.rowh .av{margin:0}.av.md{width:54px;height:54px;font-size:18px}.av.lg{width:78px;height:78px;font-size:26px;margin:0 auto}
.chip{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:99px;font-size:12px;font-weight:600;background:var(--soft);color:var(--mut)}
.chip.ok{background:var(--okbg);color:var(--okfg)}.chip.bad{background:var(--badbg);color:var(--badfg)}.chip.w{background:#ffffff2b;color:#fff}
.empty{text-align:center;color:var(--mut);padding:28px 8px}
.res{border-radius:14px;padding:16px;text-align:center;font-weight:600;background:var(--card);border:1px solid var(--line);margin:10px 0}
.res.ok{background:var(--okbg);border-color:var(--ok);color:var(--okfg)}.res.bad{background:var(--badbg);border-color:var(--bad);color:var(--badfg)}
.warn{background:var(--warnbg);color:var(--warnfg);border-radius:12px;padding:10px;margin:10px 0;font-size:13px}
.ib{background:none;border:0;color:var(--mut);padding:6px}
.ic{display:inline-flex;width:38px;height:38px;flex:none;border-radius:50%;align-items:center;justify-content:center;background:var(--soft);color:var(--link)}
.toast{position:fixed;left:50%;transform:translateX(-50%);bottom:100px;background:#1e293b;color:#fff;padding:11px 16px;border-radius:12px;z-index:99;max-width:90%;box-shadow:var(--sh)}.toast.ok{background:#15803d}.toast.bad{background:#b91c1c}
.mdl{position:fixed;inset:0;background:#0009;display:flex;align-items:flex-end;justify-content:center;z-index:50}
.sheet{background:var(--card);width:100%;max-width:560px;max-height:92vh;overflow:auto;border-radius:20px 20px 0 0;padding:18px 16px calc(18px + env(safe-area-inset-bottom));animation:up .22s ease}
.sheet h3{margin:0 0 6px}
.two{display:grid;grid-template-columns:1fr 1fr;gap:10px}
#reader{border-radius:14px;overflow:hidden}
.upd{position:fixed;top:0;left:0;right:0;z-index:60;background:#15803d;color:#fff;padding:10px;display:flex;gap:10px;align-items:center;justify-content:center}.upd button{border:0;border-radius:8px;padding:6px 14px;font-weight:700}
.hero{text-align:center;padding:30px 0 6px}.hero h1{margin:8px 0 4px;font-size:24px}
.logoimg{width:92px;height:92px;border-radius:50%;background:#fff;box-shadow:var(--sh)}.hlogo{width:32px;height:32px;border-radius:50%;background:#fff;margin-right:10px}
.hl{display:flex;align-items:center;font-weight:700}.sub{color:var(--mut);font-size:12px}
.heroc{background:linear-gradient(135deg,#14498c,#2563eb 62%,#3aa844);color:#fff;border-radius:20px;padding:18px;margin:10px 0;box-shadow:var(--sh)}.heroc .btn{margin:14px 0 0}
.info{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px solid var(--line)}.info:last-child{border:0}.info span:first-child{color:var(--mut)}.info span:last-child{text-align:right;word-break:break-word}
.chips{display:flex;gap:6px;flex-wrap:wrap;margin:6px 0}.chips button{border:0;border-radius:99px;padding:8px 15px;background:var(--soft);color:var(--mut);font-size:13px;font-weight:700}.chips button.on{background:var(--pri);color:#fff}
.stat{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:8px 0}.stat div{background:var(--inp);border-radius:12px;padding:10px;text-align:center}.stat b{display:block;font-size:20px}.stat span{font-size:12px;color:var(--mut)}
.kpis{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin:10px 0}.kpi{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;box-shadow:var(--sh)}.kpi b{display:block;font-size:28px;line-height:1.1}.kpi span{color:var(--mut);font-size:12px;font-weight:600}
.grid{display:grid;grid-template-columns:1fr;gap:10px}.grid>.card{margin:0}
.qrbox{background:#fff;padding:12px;border-radius:16px;display:inline-block;margin:6px 0}.qrbox img,.qrbox canvas{display:block}
.pg{height:8px;background:var(--soft);border-radius:9px;overflow:hidden;margin-top:8px}.pg i{display:block;height:100%;background:var(--ok);border-radius:9px}
.tg{border-radius:99px;padding:6px 14px;font-weight:700;font-size:13px;background:var(--soft);color:var(--mut)}.tg.on{background:var(--okbg);color:var(--okfg)}.tg.late{background:var(--warnbg);color:var(--warnfg)}
.chev{color:var(--mut);font-size:22px}
a{color:var(--link)}a[data-u]{text-decoration:underline;word-break:break-all;cursor:pointer}
.lks{display:flex;flex-direction:column;gap:8px;margin:10px 0}.lk{display:flex;align-items:center;gap:8px;width:100%;text-align:left;border:1px solid var(--line);background:var(--inp);color:var(--tx);border-radius:12px;padding:11px 12px;font-size:14px}.lk svg{flex:none}.lk span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.lk.file{color:var(--badfg)}
.seg{display:flex;background:var(--soft);border-radius:12px;padding:3px;margin:8px 0}.seg button{flex:1;border:0;background:none;color:var(--mut);padding:9px;border-radius:10px;font-weight:700}.seg button.on{background:var(--card);color:var(--tx);box-shadow:var(--sh)}
.ring{position:relative;width:116px;height:116px;margin:4px auto}.ring svg{transform:rotate(-90deg)}.ring b{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:26px}
.cal{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;text-align:center}.cal i{font-style:normal;font-size:11px;color:var(--mut)}.cal b{font-weight:600;font-size:13px;aspect-ratio:1;display:flex;align-items:center;justify-content:center;border-radius:10px;background:var(--soft);color:var(--mut)}.cal b.p{background:var(--okbg);color:var(--okfg)}.cal b.l{background:var(--warnbg);color:var(--warnfg)}.cal b.a{background:var(--badbg);color:var(--badfg)}.cal b.t{outline:2px solid var(--pri)}
.sk{height:68px;border-radius:16px;margin:10px 0;background:linear-gradient(90deg,var(--card),var(--soft),var(--card));background-size:200% 100%;animation:sh 1.2s infinite}
main>*{animation:fi .25s ease both}
@keyframes fi{from{opacity:0;transform:translateY(6px)}}@keyframes up{from{transform:translateY(30px);opacity:.5}}@keyframes sh{to{background-position:-200% 0}}
@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
@media(min-width:700px){.mdl{align-items:center}.sheet{border-radius:20px}}
@media(min-width:900px){#app.shell{max-width:none;margin:0;padding:76px 32px 40px 256px}#app.shell main{max-width:900px}.nav{top:56px;right:auto;width:224px;flex-direction:column;justify-content:flex-start;gap:4px;padding:16px 12px;border-top:0;border-right:1px solid var(--line)}.nav button{flex:none;max-width:none;flex-direction:row;gap:12px;font-size:15px;padding:12px 14px;border-radius:12px}.nav button.on{background:var(--soft)}.nav button.has::after{position:static;margin-left:auto}.grid{grid-template-columns:1fr 1fr}.kpis{grid-template-columns:repeat(4,1fr)}.toast{bottom:32px}}`;
  document.head.append(s);
  applyTheme();
  matchMedia('(prefers-color-scheme: light)').addEventListener('change',()=>{if(!localStorage.theme||localStorage.theme==='system')applyTheme()});
}
