// Draws the monthly report as canvas pages (so any language, e.g. Bengali, renders correctly).
export function renderReport(mk,D){
  const W=1240,H=1754,M=64,BL='#14498c',GR='#3aa844',TX='#0f172a',MU='#64748b',LN='#e2e8f0';
  const FONT='"Noto Sans Bengali","Noto Sans",system-ui,Arial,sans-serif';
  const F=(sz,b)=>`${b?'700':'400'} ${sz}px ${FONT}`;
  const pages=[];let x,y;
  const np=()=>{const c=mk();c.width=W;c.height=H;x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,W,H);x.textBaseline='alphabetic';pages.push({c,x});y=M};
  const T=(t,px,py,sz,b,col=TX,al='left')=>{x.font=F(sz,b);x.fillStyle=col;x.textAlign=al;x.fillText(t,px,py)};
  const fit=(t,w,sz,b)=>{x.font=F(sz,b);t=String(t??'');if(x.measureText(t).width<=w)return t;while(t.length>1&&x.measureText(t+'…').width>w)t=t.slice(0,-1);return t+'…'};
  const wrap=(t,w,sz)=>{x.font=F(sz,false);const out=[];let l='';for(const wd of String(t).split(' ')){const n=l?l+' '+wd:wd;if(x.measureText(n).width>w&&l){out.push(l);l=wd}else l=n}if(l)out.push(l);return out};
  const rr=(px,py,w,h,r)=>{x.beginPath();x.moveTo(px+r,py);x.arcTo(px+w,py,px+w,py+h,r);x.arcTo(px+w,py+h,px,py+h,r);x.arcTo(px,py+h,px,py,r);x.arcTo(px,py,px+w,py,r);x.closePath()};
  const col=p=>p>=75?GR:p>=50?'#f59e0b':'#ef4444';
  const cover=(img,px,py,s)=>{const m=Math.min(img.width,img.height);x.save();rr(px,py,s,s,10);x.clip();x.drawImage(img,(img.width-m)/2,(img.height-m)/2,m,m,px,py,s,s);x.restore()};
  const initials=n=>String(n||'?').trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase();
  const CW=W-2*M,LIM=H-M-50;

  np();
  // header
  if(D.logo)x.drawImage(D.logo,M,y,120,120);
  T(fit(D.org,CW-144,44,true),M+144,y+52,44,true,BL);
  T('Monthly Attendance Report',M+144,y+98,28,false,MU);
  T(fit(`${D.monthLabel} · ${D.batch}`,CW-144-380,28,true),W-M,y+98,28,true,TX,'right');
  y+=150;x.fillStyle=GR;x.fillRect(M,y,CW,6);y+=36;

  // summary cards
  const cards=[['Students',D.rows.length],['Class days',D.days.length],['Avg attendance',D.avg+'%'],['Late arrivals',D.lateTotal]];
  const gap=18,cw=(CW-gap*3)/4;
  cards.forEach((k,i)=>{const px=M+i*(cw+gap);x.fillStyle='#f1f5f9';rr(px,y,cw,120,16);x.fill();T(String(k[1]),px+cw/2,y+60,46,true,BL,'center');T(k[0],px+cw/2,y+98,22,false,MU,'center')});
  y+=120+40;

  // daily chart
  T('Daily attendance (students present)',M,y+24,28,true);y+=44;
  const ch=200,n=D.days.length;
  if(!n){T('No attendance recorded this month',M,y+60,24,false,MU);y+=ch}
  else{
    const mx=Math.max(1,...D.days.map(d=>d.n)),slot=CW/n,bw=Math.min(54,slot*.7);
    x.strokeStyle=LN;x.lineWidth=2;x.beginPath();x.moveTo(M,y+ch);x.lineTo(W-M,y+ch);x.stroke();
    const every=Math.ceil(24/slot);
    D.days.forEach((d,i)=>{const bh=Math.round((d.n/mx)*(ch-40)),px=M+i*slot+(slot-bw)/2;x.fillStyle=BL;rr(px,y+ch-bh,bw,Math.max(bh,2),6);x.fill();
      if(slot>=34)T(String(d.n),px+bw/2,y+ch-bh-8,20,true,TX,'center');
      if(i%every===0)T(d.date.slice(8),px+bw/2,y+ch+26,20,false,MU,'center')});
  }
  y+=ch+54;

  // analysis
  const ranked=[...D.rows].filter(r=>r.cd>0).sort((a,b)=>b.pct-a.pct);
  const low=ranked.filter(r=>r.pct<75).reverse();
  const lines=[`Average attendance is ${D.avg}% over ${D.days.length} class day${D.days.length==1?'':'s'}.`];
  if(ranked.length)lines.push(`Highest: ${ranked[0].name} (${ranked[0].pct}%).   Lowest: ${ranked[ranked.length-1].name} (${ranked[ranked.length-1].pct}%).`);
  lines.push(low.length?`Below 75% (${low.length}): ${low.slice(0,12).map(r=>r.name).join(', ')}${low.length>12?` and ${low.length-12} more`:''}.`:'No student is below 75% attendance.');
  const wl=lines.flatMap(l=>wrap(l,CW-48,24)),bh=wl.length*36+54;
  if(y+bh>LIM){np()}
  x.fillStyle='#f8fafc';rr(M,y,CW,bh,16);x.fill();x.strokeStyle=LN;x.lineWidth=2;rr(M,y,CW,bh,16);x.stroke();
  T('Analysis',M+24,y+38,26,true,BL);wl.forEach((l,i)=>T(l,M+24,y+78+i*36,24,false,TX));
  y+=bh+36;

  // table
  const C={n:M,p:M+56,nm:M+150,pr:W-M-440,lt:W-M-340,ab:W-M-250,pc:W-M-150},RH=84;
  const head=()=>{x.fillStyle=BL;rr(M,y,CW,52,10);x.fill();
    T('#',C.n+12,y+35,22,true,'#fff');T('Student',C.nm,y+35,22,true,'#fff');
    T('Present',C.pr+50,y+35,22,true,'#fff','center');T('Late',C.lt+40,y+35,22,true,'#fff','center');T('Absent',C.ab+45,y+35,22,true,'#fff','center');T('%',C.pc+75,y+35,22,true,'#fff','center');y+=60};
  if(y+52+RH>LIM)np();
  head();
  if(!D.rows.length)T('No students',M,y+40,24,false,MU);
  D.rows.forEach((r,i)=>{
    if(y+RH>LIM){np();head()}
    if(i%2===0){x.fillStyle='#f8fafc';x.fillRect(M,y,CW,RH)}
    T(String(i+1),C.n+12,y+50,22,false,MU);
    if(r.img)cover(r.img,C.p,y+10,64);else{x.fillStyle='#dbeafe';rr(C.p,y+10,64,64,10);x.fill();T(initials(r.name),C.p+32,y+52,24,true,BL,'center')}
    T(fit(r.name,C.pr-C.nm-20,26,true),C.nm,y+38,26,true);
    T(fit(`ID ${r.id} · ${r.batch}${r.old?' · Old':''}`,C.pr-C.nm-20,20,false),C.nm,y+66,20,false,MU);
    T(String(r.present),C.pr+50,y+50,26,true,TX,'center');
    T(String(r.late),C.lt+40,y+50,26,true,r.late?'#b45309':MU,'center');
    T(String(r.absent),C.ab+45,y+50,26,true,r.absent?'#dc2626':MU,'center');
    x.fillStyle=LN;rr(C.pc,y+52,150,10,5);x.fill();x.fillStyle=col(r.pct);rr(C.pc,y+52,Math.max(10,150*r.pct/100),10,5);x.fill();
    T(r.cd?r.pct+'%':'-',C.pc+75,y+40,24,true,col(r.pct),'center');
    y+=RH;
  });
  // footers
  pages.forEach((p,i)=>{x=p.x;x.fillStyle=LN;x.fillRect(M,H-M-30,CW,2);T(fit(D.org,CW-300,20,false),M,H-M+4,20,false,MU);T(`Generated ${D.generated}  ·  Page ${i+1} of ${pages.length}`,W-M,H-M+4,20,false,MU,'right')});
  return pages.map(p=>p.c);
}
