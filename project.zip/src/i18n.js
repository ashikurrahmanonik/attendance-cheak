// Bangla (বাংলা) support. English is the source language; when the language is Bangla every text that appears on
// screen is translated through the dictionary below (exact text first, then patterns, then " · " pieces).
// Switching language reloads the page. Names, numbers and other data are never touched.
export const lang=()=>localStorage.lang||'bn';
export function setLang(l){localStorage.lang=l;location.reload()}
export const useBnDigits=()=>localStorage.bnd==='1';
export function setBnDigits(on){localStorage.bnd=on?'1':'0';location.reload()}

const BN={};
const PATS=[];
const add=o=>Object.assign(BN,o);
const pat=(re,fn)=>PATS.push([re,fn]);

const D='০১২৩৪৫৬৭৮৯';
export const bnNum=s=>String(s).replace(/[0-9]/g,d=>D[d]);
export const enNum=s=>String(s).replace(/[০-৯]/g,d=>D.indexOf(d));

function exact(t){return Object.prototype.hasOwnProperty.call(BN,t)?BN[t]:null}
function pattern(t){for(const [re,fn] of PATS){const m=t.match(re);if(m)return fn(m)}return null}
// "ID 101 · Batch 9 · Old": translate each piece, keep the data pieces
function pieces(t){
  const sep=t.includes(' · ')?' · ':null;if(!sep)return null;
  let any=false;const out=t.split(sep).map(p=>{const r=one(p.trim());if(r!=null&&r!==p.trim())any=true;return r??p});
  return any?out.join(sep):null;
}
function one(t){return exact(t)??pattern(t)}
export function tx(v){
  if(lang()!=='bn')return v;
  const m=String(v).match(/^(\s*)([\s\S]*?)(\s*)$/),core=m[2];if(!core||!/[A-Za-z]/.test(core))return v;
  let r=exact(core);
  if(r==null&&core.includes(' · '))r=pieces(core);
  if(r==null)r=pattern(core);
  if(r==null&&core.includes('\n')){let any=false;const o=core.split('\n').map(l=>{const t=l.trim();if(!t)return l;const x=tx(t);if(x!==t)any=true;return x});if(any)r=o.join('\n')}
  return r==null?v:m[1]+r+m[3];
}
export function startI18n(){
  document.documentElement.lang=lang()==='bn'?'bn':'en';
  // Bengali digits typed on a Bangla keyboard are turned into normal digits, so IDs, phones and search keep working
  document.addEventListener('input',e=>{
    const el=e.target;if(!el||el.tagName!=='INPUT'||!/^(text|tel|search|password|)$/.test(el.type))return;
    if(/[০-৯]/.test(el.value)){const p=el.selectionStart;el.value=enNum(el.value);try{el.setSelectionRange(p,p)}catch{}}
  },true);
  if(lang()!=='bn')return;
  const bnd=useBnDigits();
  const skip=n=>{const p=n.parentNode;return !p||/^(SCRIPT|STYLE|TEXTAREA|TITLE)$/.test(p.nodeName)||(p.closest&&p.closest('[data-keep],a[href^="tel:"],a[href^="sms:"]'))};
  const node=n=>{if(skip(n))return;const v=n.nodeValue;let t=/[A-Za-z]/.test(v)?tx(v):v;if(bnd)t=bnNum(t);if(t!==v)n.nodeValue=t};
  const attr=el=>['placeholder','title','aria-label'].forEach(a=>{const v=el.getAttribute&&el.getAttribute(a);if(v){const t=tx(v);if(t!==v)el.setAttribute(a,t)}});
  const walk=root=>{
    if(root.nodeType===3)return node(root);
    if(root.nodeType!==1)return;
    const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT),L=[];let n;while((n=w.nextNode()))L.push(n);L.forEach(node);
    attr(root);root.querySelectorAll('[placeholder],[title],[aria-label]').forEach(attr);
  };
  const opts={childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['placeholder','title','aria-label']};
  const mo=new MutationObserver(ms=>{
    mo.disconnect();
    try{ms.forEach(m=>{if(m.type==='childList')m.addedNodes.forEach(walk);else if(m.type==='characterData')node(m.target);else attr(m.target)})}finally{mo.observe(document.body,opts)}
  });
  const go=()=>{walk(document.body);mo.observe(document.body,opts)};
  document.body?go():document.addEventListener('DOMContentLoaded',go);
}

/* ===== dictionary: A – L ===== */
add({
'(optional)':'(ঐচ্ছিক)','/ results':'/ ফলাফল',
'Abs':'অনুপ.','Absent':'অনুপস্থিত','ABS':'অনুপস্থিত','Absent, late and fee messages to guardians':'অনুপস্থিত, দেরি ও ফি-র বার্তা অভিভাবককে',
'Account active':'অ্যাকাউন্ট সক্রিয়','Active':'সক্রিয়','Active students':'সক্রিয় শিক্ষার্থী','active students':'জন সক্রিয় শিক্ষার্থী',
'Add':'যোগ করুন','Add PDF or images':'পিডিএফ বা ছবি যোগ করুন','Add another link':'আরেকটি লিংক যোগ করুন','Add course':'কোর্স যোগ করুন','Add holiday':'ছুটি যোগ করুন','Add payment':'পেমেন্ট যোগ করুন','Add staff':'স্টাফ যোগ করুন','Added':'যোগ হয়েছে',
'Add Cloudinary cloud name and preset in Settings first':'আগে সেটিংসে Cloudinary ক্লাউড নেম ও প্রিসেট দিন',
'Add teachers and set what they can see':'শিক্ষক যোগ করুন এবং কী দেখতে পারবে ঠিক করুন',
'Address':'ঠিকানা','Admin':'অ্যাডমিন','Admin sign in':'অ্যাডমিন লগইন',
'After switching it on, come back and continue.':'চালু করার পর এখানে ফিরে এসে চালিয়ে যান।',
'Afternoon batches (12:00 – 5:00 PM)':'দুপুরের ব্যাচ (১২:০০ – ৫:০০ বিকাল)',
'All':'সব','All batches':'সব ব্যাচ','All batches (whole day)':'সব ব্যাচ (পুরো দিন)','All done':'সব হয়ে গেছে','All my batches':'আমার সব ব্যাচ','All students':'সব শিক্ষার্থী','All time':'মোট',
'Allow':'অনুমতি দিন','Amount (৳)':'টাকার পরিমাণ (৳)',
'Android needs your permission to install updates from this app. Tap “Allow”, switch on “Allow from this source”, then come back here.':'অ্যাপ থেকে আপডেট ইনস্টল করতে অ্যান্ড্রয়েডের অনুমতি লাগবে। “অনুমতি দিন” চাপুন, “এই উৎস থেকে অনুমতি দিন” চালু করুন, তারপর এখানে ফিরে আসুন।',
'Announcements from your institute':'প্রতিষ্ঠানের ঘোষণা',
'App v':'অ্যাপ সংস্করণ','Appearance':'দেখতে কেমন','Arrived':'এসেছে',
'Attach PDF or images (up to 5, max 10 MB each)':'পিডিএফ বা ছবি যুক্ত করুন (সর্বোচ্চ ৫টি, প্রতিটি ১০ এমবি)',
'Attachments (untick to remove)':'সংযুক্তি (বাদ দিতে টিক তুলুন)',
'Attend':'হাজিরা','Attendance':'উপস্থিতি','Attended':'উপস্থিত','Average':'গড়','Avg attendance':'গড় উপস্থিতি',
'BTEB Computer Course':'বিটিইবি কম্পিউটার কোর্স','Foundation Course':'ফাউন্ডেশন কোর্স',
'Back':'পিছনে','Backup code':'ব্যাকআপ কোড','Bank':'ব্যাংক','Batch':'ব্যাচ','Batch name':'ব্যাচের নাম','Batches':'ব্যাচ','Batches this teacher can use':'এই শিক্ষক যে ব্যাচগুলো ব্যবহার করতে পারবেন','Batches today':'আজকের ব্যাচ','Best':'সেরা',
'Board exam (BTEB: students sit at the board, results come from the board)':'বোর্ড পরীক্ষা (বিটিইবি: শিক্ষার্থীরা বোর্ডে পরীক্ষা দেয়, ফল বোর্ড থেকে আসে)',
'Branding & fields':'প্রতিষ্ঠানের তথ্য ও ঘর','Button name':'বাটনের নাম','Calculating…':'হিসাব হচ্ছে…','Call':'কল',
'Camera error: allow camera permission and reopen this tab':'ক্যামেরা ত্রুটি: ক্যামেরার অনুমতি দিন এবং ট্যাবটি আবার খুলুন',
'Cancel':'বাতিল','Cancel it':'বাতিল করুন','Cancel selection':'নির্বাচন বাতিল','Cancel this scheduled notification?':'এই নির্ধারিত নোটিফিকেশন বাতিল করবেন?','Cancelled':'বাতিল হয়েছে','Cash':'নগদ টাকা',
'Certificate':'সার্টিফিকেট','Certificate desk':'সার্টিফিকেট ডেস্ক','Certificate handed over':'সার্টিফিকেট হস্তান্তর হয়েছে','Certificate number (optional)':'সার্টিফিকেট নম্বর (ঐচ্ছিক)','Certificates':'সার্টিফিকেট','Certificates and 360° student profile':'সার্টিফিকেট ও ৩৬০° শিক্ষার্থী প্রোফাইল','Certificates arrived':'সার্টিফিকেট এসেছে','Certificates given':'সার্টিফিকেট দেওয়া হয়েছে',
'Change ID':'আইডি পরিবর্তন','Changing the result type clears the marks/grades already entered. Continue?':'ফলাফলের ধরন বদলালে আগে দেওয়া নম্বর/গ্রেড মুছে যাবে। চালিয়ে যাবেন?',
'Check for updates':'আপডেট আছে কি দেখুন','Check full marks and pass marks':'পূর্ণমান ও পাস নম্বর দেখে নিন','Choose at least one batch':'কমপক্ষে একটি ব্যাচ বেছে নিন','Choose batches…':'ব্যাচ বেছে নিন…','Choose batch…':'ব্যাচ বেছে নিন…','Choose the new batch':'নতুন ব্যাচ বেছে নিন',
'Choose the course in each batch. The fee here is used for every student of that batch unless you set a different fee for a batch or a student.':'প্রতিটি ব্যাচে কোর্স বেছে নিন। ব্যাচ বা শিক্ষার্থীর আলাদা ফি না দিলে এখানকার ফি ওই ব্যাচের সবার জন্য ধরা হবে।',
'Choose the grade of each student (as received from the board / given by you)':'প্রতিটি শিক্ষার্থীর গ্রেড বেছে নিন (বোর্ড থেকে পাওয়া / আপনার দেওয়া)',
'Clear':'মুছুন','Close':'বন্ধ করুন','Cloud name':'ক্লাউড নেম','Cloudinary (photos, logo, notice files)':'Cloudinary (ছবি, লোগো, নোটিশের ফাইল)',
'Collect the due, or tick “Hand over anyway”':'বাকি টাকা নিন, অথবা “তবুও হস্তান্তর করুন” টিক দিন',
'Collected':'আদায়','Collected in':'আদায় হয়েছে','Collected in month':'যে মাসে আদায়','Contact':'যোগাযোগ','Continue':'চালিয়ে যান','Copied':'কপি হয়েছে','Copy':'কপি',
'Could not read release info':'রিলিজের তথ্য পড়া যায়নি','Could not save:':'সংরক্ষণ করা যায়নি:','Could not set up notifications. Check your internet and try again.':'নোটিফিকেশন চালু করা যায়নি। ইন্টারনেট দেখে আবার চেষ্টা করুন।',
'Count class days from':'ক্লাসের দিন গণনা শুরু','Count fee dues from month':'যে মাস থেকে বাকি গণনা','Course':'কোর্স','Course completed':'কোর্স শেষ','Course fee':'কোর্স ফি','Courses & course fees':'কোর্স ও কোর্স ফি',
'Cover image (shows big in the notification and the app)':'কভার ছবি (নোটিফিকেশন ও অ্যাপে বড় করে দেখাবে)',
'Cracked screen? Enter backup code':'স্ক্রিন ভাঙা? ব্যাকআপ কোড দিন',
'Create a batch first':'আগে একটি ব্যাচ তৈরি করুন','Create account':'অ্যাকাউন্ট তৈরি করুন','Create exams, enter marks, result sheets':'পরীক্ষা তৈরি, নম্বর দেওয়া, ফলাফল শিট','Create missing student QR keys':'বাকি শিক্ষার্থীদের QR কী তৈরি করুন','Creating…':'তৈরি হচ্ছে…',
'Create one, e.g. “Batch 9” 09:00 – 10:00.':'একটি তৈরি করুন, যেমন “ব্যাচ ৯” ০৯:০০ – ১০:০০।',
'Custom message (optional)':'নিজের বার্তা (ঐচ্ছিক)','Date':'তারিখ','Days attended':'উপস্থিত দিন','Days before this date only count if attendance was taken.':'এই তারিখের আগের দিনগুলো তখনই গণনায় আসবে যদি হাজিরা নেওয়া হয়ে থাকে।',
'Default “late after” minutes':'ডিফল্ট “দেরি” মিনিট','Delete':'মুছুন','Delete batch':'ব্যাচ মুছুন','Delete exam':'পরীক্ষা মুছুন','Delete this announcement?':'এই ঘোষণা মুছবেন?','Delete this holiday?':'এই ছুটি মুছবেন?','Deleted':'মুছে গেছে',
'Discard':'বাদ দিন','Discard this offline record? It will NOT be uploaded.':'এই অফলাইন রেকর্ড বাদ দেবেন? এটি আপলোড হবে না।','Do not notify':'নোটিফিকেশন দেবেন না','Done':'হয়েছে',
'Download Excel (CSV)':'এক্সেল (CSV) ডাউনলোড','Download PDF (with photos)':'পিডিএফ ডাউনলোড (ছবি সহ)','Download PDF report':'পিডিএফ রিপোর্ট ডাউনলোড','Download cancelled':'ডাউনলোড বাতিল হয়েছে','Due':'বাকি','Dues list (PDF)':'বাকির তালিকা (পিডিএফ)',
'Edit':'সম্পাদনা','Edit announcement':'ঘোষণা সম্পাদনা','Edit batch':'ব্যাচ সম্পাদনা','Email':'ইমেইল','Email (login)':'ইমেইল (লগইনের জন্য)','Empty':'খালি','End':'শেষ','Ended':'শেষ হয়েছে','Enter':'দিন',
'Enter ID, name and a valid mobile number':'আইডি, নাম ও সঠিক মোবাইল নম্বর দিন','Enter a name and a fee':'নাম ও ফি দিন','Enter a name and a valid email':'নাম ও সঠিক ইমেইল দিন','Enter a title and a date':'শিরোনাম ও তারিখ দিন','Enter a valid amount':'সঠিক টাকার পরিমাণ দিন','Enter exam name and date':'পরীক্ষার নাম ও তারিখ দিন','Enter the 6-digit code':'৬ সংখ্যার কোড দিন','Enter the transaction ID (at least 6 letters/numbers)':'ট্রানজেকশন আইডি দিন (কমপক্ষে ৬টি অক্ষর/সংখ্যা)',
'Error:':'ত্রুটি:','Evening batches (after 5:00 PM)':'সন্ধ্যার ব্যাচ (বিকাল ৫:০০ এর পর)','Event':'অনুষ্ঠান',
'Every QR from the new Student app is signed with a secret key, so nobody can make a QR for another student. Turn this on after all students have updated the app.':'নতুন অ্যাপের প্রতিটি QR গোপন কী দিয়ে সাইন করা, তাই কেউ অন্যের QR বানাতে পারবে না। সবাই অ্যাপ আপডেট করার পর এটি চালু করুন।',
'Everyone who sat this exam gets a notification to collect the certificate.':'যারা এই পরীক্ষা দিয়েছে সবাই সার্টিফিকেট নিতে নোটিফিকেশন পাবে।',
'Exam':'পরীক্ষা','Exam center (board)':'পরীক্ষা কেন্দ্র (বোর্ড)','Exam day, 7:00 AM':'পরীক্ষার দিন, সকাল ৭:০০','Exam name':'পরীক্ষার নাম','Exam students':'পরীক্ষার শিক্ষার্থী','Exam type':'পরীক্ষার ধরন','Exams & certificates':'পরীক্ষা ও সার্টিফিকেট','Exams & results':'পরীক্ষা ও ফলাফল','Exams':'পরীক্ষা',
'Export all students (CSV)':'সব শিক্ষার্থী এক্সপোর্ট (CSV)','Extra student fields (comma separated)':'অতিরিক্ত তথ্যের ঘর (কমা দিয়ে)','Fail':'অকৃতকার্য',
'Father':'পিতা','Father’s name':'পিতার নাম','Fee':'ফি','Fee (৳)':'ফি (৳)','Fee due':'ফি বাকি','Fee dues list':'ফি বাকির তালিকা','Fee must be a number':'ফি সংখ্যায় দিন','Fee override (৳)':'আলাদা ফি (৳)','Fee type':'ফি-র ধরন','Fees':'ফি','Fees & payments':'ফি ও পেমেন্ট','Fill all fields':'সব ঘর পূরণ করুন',
'Finish course: mark all':'কোর্স শেষ: সবাইকে চিহ্নিত করুন','Flip':'ঘোরান','For':'বাবদ','For month':'যে মাসের জন্য','From':'থেকে',
'Full backup of every student (all fields) as a spreadsheet.':'প্রতিটি শিক্ষার্থীর পূর্ণ তথ্য স্প্রেডশিটে ব্যাকআপ।','Full marks':'পূর্ণমান','Full name':'পূর্ণ নাম',
'Gives every student a private QR key (needed for signed QR). Safe to run again.':'প্রতিটি শিক্ষার্থীকে নিজস্ব QR কী দেয় (সাইন করা QR-এর জন্য দরকার)। আবার চালালেও সমস্যা নেই।',
'Good afternoon':'শুভ অপরাহ্ন','Good evening':'শুভ সন্ধ্যা','Good morning':'শুভ সকাল','Grade':'গ্রেড','Grade only (A+, A, B…)':'শুধু গ্রেড (A+, A, B…)','Guardian':'অভিভাবক','Guardian mobile':'অভিভাবকের মোবাইল','Guardian mobile (for absence / fee messages)':'অভিভাবকের মোবাইল (অনুপস্থিতি / ফি-র বার্তার জন্য)',
'Hand over':'হস্তান্তর করুন','History':'ইতিহাস','Holiday':'ছুটি','Holiday range is too long (max 120 days)':'ছুটির সময়সীমা অনেক বড় (সর্বোচ্চ ১২০ দিন)','Holidays':'ছুটি','Holidays & weekly off':'ছুটি ও সাপ্তাহিক ছুটি','Holidays are not counted as class days':'ছুটির দিন ক্লাসের দিন হিসেবে গণনা হয় না',
'Holidays are not counted as class days. Weekly off days (like Friday) are set in each batch.':'ছুটির দিন ক্লাসের দিন হিসেবে গণনা হয় না। সাপ্তাহিক ছুটি (যেমন শুক্রবার) প্রতিটি ব্যাচে ঠিক করা হয়।',
'Home':'হোম','ID':'আইডি','ID & password list':'আইডি ও পাসওয়ার্ড তালিকা','ID cannot contain spaces, / or |':'আইডিতে স্পেস, / বা | থাকতে পারবে না','ID, Name, Mobile, Batch':'আইডি, নাম, মোবাইল, ব্যাচ',
'If you can read this, push is working.':'এটি পড়তে পারলে নোটিফিকেশন কাজ করছে।','Import':'ইমপোর্ট','Import students':'শিক্ষার্থী ইমপোর্ট','Important':'গুরুত্বপূর্ণ','In session':'ক্লাস চলছে',
'Install':'ইনস্টল','Institute exam (we take it, marks or grade)':'প্রতিষ্ঠানের পরীক্ষা (আমরা নিই, নম্বর বা গ্রেড)','Institute name':'প্রতিষ্ঠানের নাম','Institute name, logo, custom fields, photos':'প্রতিষ্ঠানের নাম, লোগো, অতিরিক্ত ঘর, ছবি',
'Invalid QR. Ask the student to close and reopen the app, then show the QR again.':'QR সঠিক নয়। শিক্ষার্থীকে অ্যাপ বন্ধ করে আবার খুলে QR দেখাতে বলুন।','Invalid batch name':'ব্যাচের নাম সঠিক নয়','Invalid link:':'লিংক সঠিক নয়:',
'Joined':'ভর্তি','Last 7 days · students present':'গত ৭ দিন · উপস্থিত শিক্ষার্থী','Late':'দেরি','Late today':'আজ দেরি','Later':'পরে','Leave empty to use the standard message':'খালি রাখলে সাধারণ বার্তা যাবে','Left':'ছেড়েছে','Light':'আলো','Light is not available on this camera':'এই ক্যামেরায় আলো নেই','Links':'লিংক','Links typed here become tappable':'এখানে লেখা লিংক চাপ দেওয়ার মতো হবে',
'Log out':'লগ আউট','Log out of admin?':'অ্যাডমিন থেকে লগ আউট করবেন?','Log out of this device?':'এই ডিভাইস থেকে লগ আউট করবেন?','Login':'লগইন','Login details':'লগইনের তথ্য','Login list':'লগইন তালিকা','Login with your Student ID and mobile number':'আপনার স্টুডেন্ট আইডি ও মোবাইল নম্বর দিয়ে লগইন করুন','Logo (optional, replaces the default)':'লোগো (ঐচ্ছিক, ডিফল্টের জায়গায় বসবে)',
});

/* ===== dictionary: M – Z ===== */
add({
'Maintenance':'রক্ষণাবেক্ষণ','Manual':'ম্যানুয়াল','Mark':'চিহ্নিত করুন','Mark as Active':'সক্রিয় করুন','Mark as Old':'পুরাতন করুন','Mark certificates as arrived and notify':'সার্টিফিকেট এসেছে চিহ্নিত করে জানান',
'Mark “late” after (minutes from start)':'শুরুর কত মিনিট পর “দেরি” ধরা হবে','Marks':'নম্বর','Marks (grade is calculated)':'নম্বর (গ্রেড নিজে হিসাব হবে)','Maximum 5 files':'সর্বোচ্চ ৫টি ফাইল','Maximum 5 links':'সর্বোচ্চ ৫টি লিংক',
'Message':'বার্তা','Message (optional)':'বার্তা (ঐচ্ছিক)','Message guardians':'অভিভাবককে বার্তা','Message these guardians':'এই অভিভাবকদের বার্তা দিন','Messages':'বার্তা','Method':'পদ্ধতি','Mobile':'মোবাইল','Mobile number':'মোবাইল নম্বর','Mobile number (this is the login password)':'মোবাইল নম্বর (এটিই লগইনের পাসওয়ার্ড)',
'Month':'মাস','Monthly fee':'মাসিক ফি','Monthly fee: where to start counting?':'মাসিক ফি: কোন মাস থেকে গণনা শুরু?','Monthly fees, payments, receipts and dues':'মাসিক ফি, পেমেন্ট, রসিদ ও বাকি','Months':'মাস','More':'আরও',
'More than one student has this code right now. Pick the right one.':'এই মুহূর্তে একাধিক শিক্ষার্থীর এই কোড আছে। সঠিক জনকে বেছে নিন।','Morning batches (before 12:00)':'সকালের ব্যাচ (১২:০০ এর আগে)','Mother':'মাতা','Mother’s name':'মাতার নাম','Move':'সরান','Move all active students to':'সব সক্রিয় শিক্ষার্থীকে সরান','Move students who got the certificate to Old':'সার্টিফিকেট পাওয়া শিক্ষার্থীদের পুরাতনে সরান','Move this student to Old students':'এই শিক্ষার্থীকে পুরাতন শিক্ষার্থীতে সরান','Moved':'সরানো হয়েছে','Moved to Old students':'পুরাতন শিক্ষার্থীতে সরানো হয়েছে',
'My attendance QR':'আমার হাজিরার QR','Nagad':'নগদ','Name':'নাম','Name in Bangla (optional)':'বাংলায় নাম (ঐচ্ছিক)','Name of the person':'ব্যক্তির নাম','Needs attention':'নজর দিতে হবে','New announcement':'নতুন ঘোষণা','New batch':'নতুন ব্যাচ','New exam':'নতুন পরীক্ষা','Next month':'পরের মাস',
'No access':'প্রবেশের অনুমতি নেই','No announcements yet':'এখনও কোনো ঘোষণা নেই','No batch matches yet. Choose batches.':'কোনো ব্যাচ মেলেনি। ব্যাচ বেছে নিন।','No batch selected':'কোনো ব্যাচ বাছা হয়নি','No batch selected. This teacher will not see any student. Continue?':'কোনো ব্যাচ বাছা হয়নি। এই শিক্ষক কোনো শিক্ষার্থী দেখবেন না। চালিয়ে যাবেন?',
'No batches yet.':'এখনও কোনো ব্যাচ নেই।','No class today. Enjoy your day off!':'আজ ক্লাস নেই। ছুটির দিন উপভোগ করুন!','No dues':'কোনো বাকি নেই','No dues. Thank you!':'কোনো বাকি নেই। ধন্যবাদ!','No exam results for this student yet':'এই শিক্ষার্থীর এখনও কোনো ফল নেই','No exam results yet.':'এখনও কোনো পরীক্ষার ফল নেই।','No exams yet':'এখনও কোনো পরীক্ষা নেই',
'No exams yet. Create one to set the date, students and reminder.':'এখনও কোনো পরীক্ষা নেই। তারিখ, শিক্ষার্থী ও রিমাইন্ডার দিয়ে একটি তৈরি করুন।','No internet connection':'ইন্টারনেট সংযোগ নেই','No payments yet':'এখনও কোনো পেমেন্ট নেই','No records':'কোনো রেকর্ড নেই','No records yet':'এখনও কোনো রেকর্ড নেই','No reminder':'রিমাইন্ডার নয়','No staff yet':'এখনও কোনো স্টাফ নেই','No student found':'কোনো শিক্ষার্থী পাওয়া যায়নি','No students':'কোনো শিক্ষার্থী নেই','No students found':'কোনো শিক্ষার্থী পাওয়া যায়নি','No students to show':'দেখানোর মতো শিক্ষার্থী নেই','No upcoming holidays':'আসন্ন কোনো ছুটি নেই','No weekly off':'সাপ্তাহিক ছুটি নেই','Nobody to message':'বার্তা দেওয়ার মতো কেউ নেই','Nobody to move':'সরানোর মতো কেউ নেই','Nobody yet':'এখনও কেউ নেই','Not marked today':'আজ হাজিরা হয়নি','Not marked yet':'এখনও হাজিরা হয়নি',
'Note (optional)':'নোট (ঐচ্ছিক)','Note for students (what to bring…)':'শিক্ষার্থীদের জন্য নোট (কী আনতে হবে…)','Nothing to import':'ইমপোর্ট করার কিছু নেই','Nothing to show':'দেখানোর কিছু নেই','Nothing to upload':'আপলোডের কিছু নেই','Notice':'নোটিশ','Notices':'নোটিশ',
'Notices reach students even when their app is closed. Follow the Worker setup steps once. Leave empty to turn push off.':'অ্যাপ বন্ধ থাকলেও শিক্ষার্থীরা নোটিশ পাবে। Worker সেটআপ একবার করুন। খালি রাখলে নোটিফিকেশন বন্ধ থাকবে।',
'Notification':'নোটিফিকেশন','Notifications':'নোটিফিকেশন','Notifications are off.':'নোটিফিকেশন বন্ধ আছে।','Notifications are on. You will get notices even when the app is closed.':'নোটিফিকেশন চালু আছে। অ্যাপ বন্ধ থাকলেও নোটিশ পাবেন।','Notify':'জানান','Notify again':'আবার জানান','Notify students':'শিক্ষার্থীদের জানান','Notify students again (phone notification)':'শিক্ষার্থীদের আবার জানান (ফোন নোটিফিকেশন)',
'Off / holiday':'বন্ধ / ছুটি','Off days and holidays are not counted as class days, so they never lower attendance %.':'ছুটির দিন ক্লাসের দিন হিসেবে গণনা হয় না, তাই উপস্থিতির হার কমে না।','Offline and no saved student list. Open the Scan tab once with internet.':'অফলাইন এবং শিক্ষার্থীর তালিকা সংরক্ষিত নেই। একবার ইন্টারনেট দিয়ে স্ক্যান ট্যাব খুলুন।','Offline mode.':'অফলাইন মোড।','Old':'পুরাতন','Old app version. Ask the student to update the app.':'অ্যাপের পুরনো সংস্করণ। শিক্ষার্থীকে অ্যাপ আপডেট করতে বলুন।','Old student':'পুরাতন শিক্ষার্থী','Old student (course finished)':'পুরাতন শিক্ষার্থী (কোর্স শেষ)',
'Old students keep their history and reports, but leave the daily lists and fee dues.':'পুরাতন শিক্ষার্থীদের ইতিহাস ও রিপোর্ট থাকে, কিন্তু দৈনিক তালিকা ও ফি-র বাকি থেকে বাদ যায়।',
'On Xiaomi, Oppo, Vivo, Realme or Samsung phones: Settings → Battery → this app →':'শাওমি, অপো, ভিভো, রিয়েলমি বা স্যামসাং ফোনে: সেটিংস → ব্যাটারি → এই অ্যাপ →',
'One course fee (installments)':'একটি কোর্স ফি (কিস্তিতে)','One student per line:':'প্রতি লাইনে একজন শিক্ষার্থী:','Only for courses with a monthly fee. Dues are counted from each student’s joining month. If students joined before you started using this app, pick the first month to count.':'শুধু মাসিক ফি-র কোর্সের জন্য। প্রতিটি শিক্ষার্থীর ভর্তির মাস থেকে বাকি গণনা হয়। যারা এই অ্যাপ ব্যবহারের আগে ভর্তি হয়েছে, তাদের জন্য গণনার প্রথম মাস বেছে নিন।',
'Open in browser instead':'বদলে ব্রাউজারে খুলুন','Open installer again':'ইনস্টলার আবার খুলুন','Opening the installer…':'ইনস্টলার খোলা হচ্ছে…','Other':'অন্য',
'PDF failed:':'পিডিএফ হয়নি:','Paid':'পরিশোধিত','Partial':'আংশিক','Pass':'উত্তীর্ণ','Pass marks':'পাস নম্বর','Password':'পাসওয়ার্ড','Password (min 6)':'পাসওয়ার্ড (কমপক্ষে ৬)','Password (mobile)':'পাসওয়ার্ড (মোবাইল)','Password must be at least 6 characters':'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে','Past':'অতীত','Payment history':'পেমেন্টের ইতিহাস','Payment saved. Download the receipt now?':'পেমেন্ট সংরক্ষিত। এখনই রসিদ ডাউনলোড করবেন?','Payments':'পেমেন্ট','Pending':'অপেক্ষমাণ','Percent':'শতাংশ',
'Phone notifications (Cloudflare Worker)':'ফোন নোটিফিকেশন (Cloudflare Worker)','Photo (optional)':'ছবি (ঐচ্ছিক)','Pick a month':'একটি মাস বেছে নিন','Pin':'পিন','Pin to top':'উপরে পিন করুন','Please pay at the office.':'অনুগ্রহ করে অফিসে পরিশোধ করুন।','Preparing PDF…':'পিডিএফ তৈরি হচ্ছে…','Present':'উপস্থিত','Present today':'আজ উপস্থিত','Previous month':'আগের মাস','Profile':'প্রোফাইল','Progress chart':'অগ্রগতির চার্ট','Push failed (':'পুশ ব্যর্থ (',
'Push notifications work in the installed Android app.':'নোটিফিকেশন ইনস্টল করা অ্যান্ড্রয়েড অ্যাপে কাজ করে।','Push server is not reachable':'নোটিফিকেশন সার্ভারে পৌঁছানো যাচ্ছে না','Rank':'র‍্যাংক','Reactivate':'আবার সক্রিয় করুন','Rebuild class-day index':'ক্লাসের দিনের তালিকা নতুন করে বানান','Receipt':'রসিদ','Receipt failed:':'রসিদ হয়নি:','Receipt footer text':'রসিদের নিচের লেখা','Receipt voided':'রসিদ বাতিল হয়েছে','Received by':'গ্রহণকারী','Recent':'সাম্প্রতিক','Record payment now':'এখনই পেমেন্ট নথিভুক্ত করুন','Refresh':'রিফ্রেশ',
'Refreshes every 15 seconds. Show it to the admin to be scanned. Keep the screen brightness up.':'প্রতি ১৫ সেকেন্ডে বদলায়। অ্যাডমিনকে স্ক্যান করতে দেখান। স্ক্রিনের আলো বাড়িয়ে রাখুন।','Reject QR codes from old app versions':'পুরনো অ্যাপের QR বাতিল করুন','Reminder cancelled':'রিমাইন্ডার বাতিল হয়েছে','Reminder to these students':'এই শিক্ষার্থীদের রিমাইন্ডার','Remove':'সরিয়ে ফেলুন','Rename':'নাম বদলান','Report by (time)':'কখনের মধ্যে আসতে হবে','Report card':'রিপোর্ট কার্ড','Reports':'রিপোর্ট','Reset email sent':'রিসেট ইমেইল পাঠানো হয়েছে','Reset text':'লেখা রিসেট','Result':'ফলাফল','Result sheet':'ফলাফল শিট','Result type':'ফলাফলের ধরন','Results':'ফলাফল','Results saved':'ফলাফল সংরক্ষিত','Rocket':'রকেট','Role':'ভূমিকা',
'Run this once if attendance was recorded before this version, so students’ monthly % and calendar are correct.':'এই সংস্করণের আগে হাজিরা নেওয়া হয়ে থাকলে একবার চালান, তাহলে শিক্ষার্থীদের মাসিক শতাংশ ও ক্যালেন্ডার ঠিক হবে।','Same day, 7:00 AM':'একই দিন, সকাল ৭:০০',
'Save':'সংরক্ষণ','Save anyway':'তবুও সংরক্ষণ করুন','Save changes':'পরিবর্তন সংরক্ষণ','Save holiday':'ছুটি সংরক্ষণ','Save payment':'পেমেন্ট সংরক্ষণ','Save results':'ফলাফল সংরক্ষণ','Save the Worker URL first':'আগে Worker URL সংরক্ষণ করুন','Saved':'সংরক্ষিত','Saved and students notified again':'সংরক্ষিত এবং শিক্ষার্থীদের আবার জানানো হয়েছে','Saved as default':'ডিফল্ট হিসেবে সংরক্ষিত','Saved. Reminder sent':'সংরক্ষিত। রিমাইন্ডার পাঠানো হয়েছে','Saving…':'সংরক্ষণ হচ্ছে…',
'Scan':'স্ক্যান','Scan QR now':'এখনই QR স্ক্যান করুন','Scan security':'স্ক্যানের নিরাপত্তা','Scan student QR':'শিক্ষার্থীর QR স্ক্যান করুন','Scans are saved on this phone and uploaded when internet returns.':'স্ক্যান এই ফোনে জমা থাকে এবং ইন্টারনেট এলে আপলোড হয়।','Scheduled':'নির্ধারিত','Screen cracked or QR not scanning? Tell this code to the admin.':'স্ক্রিন ভাঙা বা QR স্ক্যান হচ্ছে না? অ্যাডমিনকে এই কোডটি বলুন।',
'Search':'খুঁজুন','Search name or ID':'নাম বা আইডি দিয়ে খুঁজুন','Search name, ID, mobile or batch':'নাম, আইডি, মোবাইল বা ব্যাচ দিয়ে খুঁজুন','Search student: name, ID, mobile, certificate no':'শিক্ষার্থী খুঁজুন: নাম, আইডি, মোবাইল, সার্টিফিকেট নম্বর','Select all shown':'দেখানো সবাইকে বাছুন','Select several…':'কয়েকজনকে বাছুন…','Select students first':'আগে শিক্ষার্থী বাছুন','Select the students, or choose “No reminder”':'শিক্ষার্থী বাছুন, অথবা “রিমাইন্ডার নয়” বেছে নিন',
'Send':'পাঠান','Send announcements to students':'শিক্ষার্থীদের ঘোষণা পাঠান','Send now':'এখনই পাঠান','Send password reset email':'পাসওয়ার্ড রিসেট ইমেইল পাঠান','Send phone notification (works when the app is closed)':'ফোন নোটিফিকেশন পাঠান (অ্যাপ বন্ধ থাকলেও কাজ করে)','Send test notification to all students':'সব শিক্ষার্থীকে পরীক্ষামূলক নোটিফিকেশন পাঠান','Send to':'যাদের পাঠাবেন','Send to next ▶':'পরের জনকে পাঠান ▶','Sending…':'পাঠানো হচ্ছে…','Sent':'পাঠানো হয়েছে','Sent with phone notification':'ফোন নোটিফিকেশন সহ পাঠানো হয়েছে',
'Setting up…':'চালু হচ্ছে…','Settings':'সেটিংস','Share':'শেয়ার','Show report':'রিপোর্ট দেখুন','Sign in':'সাইন ইন','Sign out':'সাইন আউট','Someone else':'অন্য কেউ','Something went wrong:':'কিছু ভুল হয়েছে:','Sound on':'শব্দ চালু','Staff':'স্টাফ','Staff & roles':'স্টাফ ও ভূমিকা','Staff added':'স্টাফ যোগ হয়েছে','Start':'শুরু','Starts':'শুরু','Status':'অবস্থা','Streak':'ধারাবাহিকতা',
'Student':'শিক্ষার্থী','Student ID':'স্টুডেন্ট আইডি','Student ID & password list (PDF with photos)':'স্টুডেন্ট আইডি ও পাসওয়ার্ড তালিকা (ছবি সহ পিডিএফ)','Student ID (user ID for login)':'স্টুডেন্ট আইডি (লগইনের ইউজার আইডি)','Student ID (user)':'স্টুডেন্ট আইডি (ইউজার)','Student ID or mobile number is wrong':'স্টুডেন্ট আইডি বা মোবাইল নম্বর ভুল','Student login list':'শিক্ষার্থীর লগইন তালিকা','Student mobile':'শিক্ষার্থীর মোবাইল','Students':'শিক্ষার্থী','Students in this exam':'এই পরীক্ষার শিক্ষার্থী','Students notified':'শিক্ষার্থীদের জানানো হয়েছে','Students…':'শিক্ষার্থী…','Subject (optional)':'বিষয় (ঐচ্ছিক)','Sync':'সিঙ্ক',
'Tap':'চাপুন','Tap to close':'বন্ধ করতে চাপুন','Tap to read':'পড়তে চাপুন','Test notification':'পরীক্ষামূলক নোটিফিকেশন','Test sent':'পরীক্ষামূলক বার্তা পাঠানো হয়েছে','Thank you. This is a computer generated receipt.':'ধন্যবাদ। এটি কম্পিউটারে তৈরি রসিদ।',
'The certificate for “BTEB Board Exam” has arrived. Please collect it from the office.':'“BTEB Board Exam” পরীক্ষার সার্টিফিকেট অফিসে এসেছে। অনুগ্রহ করে অফিস থেকে সংগ্রহ করুন।','The downloaded file is incomplete. Please try again.':'ডাউনলোড করা ফাইল অসম্পূর্ণ। আবার চেষ্টা করুন।','The student himself / herself':'শিক্ষার্থী নিজে','The student opens the Student app → Home and shows the QR. Hold steady about 20–30 cm away.':'শিক্ষার্থী স্টুডেন্ট অ্যাপ → হোম খুলে QR দেখাবে। ২০–৩০ সেমি দূরে স্থির ধরে রাখুন।','The student’s app shows a 6-digit backup code under the QR. Type it here.':'শিক্ষার্থীর অ্যাপে QR-এর নিচে ৬ সংখ্যার ব্যাকআপ কোড থাকে। এখানে লিখুন।','The teacher signs in to this same Admin app with this email and password.':'শিক্ষক এই একই অ্যাডমিন অ্যাপে এই ইমেইল ও পাসওয়ার্ড দিয়ে সাইন ইন করবেন।','The update downloads inside this app and installs over it. Your login and data stay safe.':'আপডেট অ্যাপের ভেতরেই ডাউনলোড হয়ে ইনস্টল হবে। আপনার লগইন ও তথ্য নিরাপদ থাকবে।',
'There must be at least one active owner':'কমপক্ষে একজন সক্রিয় মালিক থাকতে হবে','They will appear here after your teacher publishes them.':'শিক্ষক প্রকাশ করার পর এখানে দেখা যাবে।','This ID already exists':'এই আইডি আগে থেকেই আছে','This batch already exists':'এই ব্যাচ আগে থেকেই আছে','This email already has a login. Add it to the staff list without changing its password?':'এই ইমেইলে আগে থেকেই লগইন আছে। পাসওয়ার্ড না বদলে স্টাফ তালিকায় যোগ করবেন?','This email is already in the staff list':'এই ইমেইল স্টাফ তালিকায় আছে','This file is not a valid image':'এই ফাইলটি সঠিক ছবি নয়','This is not a student QR':'এটি শিক্ষার্থীর QR নয়','This month':'এই মাস',
'This older version can only update through the browser. Install the new APK once, after that updates happen inside the app.':'এই পুরনো সংস্করণ শুধু ব্রাউজার দিয়ে আপডেট হয়। নতুন APK একবার ইনস্টল করুন, এরপর থেকে অ্যাপের ভেতরেই আপডেট হবে।','Tick a batch above to see its students.':'শিক্ষার্থী দেখতে উপরে একটি ব্যাচে টিক দিন।','Time, weekly off, fee, finish course or move students':'সময়, সাপ্তাহিক ছুটি, ফি, কোর্স শেষ বা শিক্ষার্থী সরানো','Title':'শিরোনাম','To':'পর্যন্ত','Today':'আজ','Tomorrow':'আগামীকাল','Total fees':'মোট ফি','Transaction ID':'ট্রানজেকশন আইডি','Try again':'আবার চেষ্টা করুন','Turn off':'বন্ধ করুন','Turn on':'চালু করুন','Turn on Email/Password sign-in in Firebase → Authentication.':'Firebase → Authentication এ Email/Password সাইন-ইন চালু করুন।','Type':'ধরন','Type to find a student and see the full profile: dues, results and certificates.':'লিখে শিক্ষার্থী খুঁজুন এবং পূর্ণ প্রোফাইল দেখুন: বাকি, ফলাফল ও সার্টিফিকেট।',
'Undo':'ফিরিয়ে নিন','Unknown student':'অজানা শিক্ষার্থী','Unrestricted':'সীমাহীন','Unsigned upload preset':'Unsigned আপলোড প্রিসেট','Upcoming':'আসন্ন','Upcoming and current':'আসন্ন ও চলমান','Update available':'আপডেট এসেছে','Update failed':'আপডেট ব্যর্থ','Update now':'এখনই আপডেট করুন','Update source is not configured':'আপডেটের উৎস ঠিক করা নেই','Updates work inside the installed app':'আপডেট ইনস্টল করা অ্যাপের ভেতরে কাজ করে','Uploaded':'আপলোড হয়েছে','Uploading image…':'ছবি আপলোড হচ্ছে…',
'Venue':'স্থান','Venue / room':'স্থান / কক্ষ','Version':'সংস্করণ','View':'দেখুন','Void':'বাতিল','Void receipt':'রসিদ বাতিল','WA':'WA','Waiting':'অপেক্ষায়','Waiting for a QR…':'QR এর অপেক্ষায়…','Waiting to upload':'আপলোডের অপেক্ষায়','Waiver':'মওকুফ','Waiver / discount':'মওকুফ / ছাড়','Weekly off':'সাপ্তাহিক ছুটি','Weekly off days':'সাপ্তাহিক ছুটির দিন','WhatsApp':'হোয়াটসঅ্যাপ','Which student?':'কোন শিক্ষার্থী?','Who has the holiday?':'কাদের ছুটি?','Worker URL':'Worker URL','Working…':'কাজ চলছে…','Write a title':'একটি শিরোনাম লিখুন','Wrong email or password':'ইমেইল বা পাসওয়ার্ড ভুল','Wrong or expired code. Ask the student for the current code.':'কোড ভুল বা মেয়াদ শেষ। শিক্ষার্থীর কাছ থেকে বর্তমান কোড জেনে নিন।','Yes':'হ্যাঁ',
'You are listed as an old student. Attendance is closed for your account. You can still see your profile and history.':'আপনি পুরাতন শিক্ষার্থী হিসেবে তালিকাভুক্ত। আপনার অ্যাকাউন্টে হাজিরা বন্ধ। প্রোফাইল ও ইতিহাস দেখতে পারবেন।','You are offline. Data may be out of date.':'আপনি অফলাইনে আছেন। তথ্য পুরনো হতে পারে।','You can paste straight from Excel. The batch must already exist.':'সরাসরি এক্সেল থেকে পেস্ট করতে পারেন। ব্যাচ আগে থেকে থাকতে হবে।','You can rename it. Students, attendance history, exams and notices are updated automatically.':'নাম বদলাতে পারেন। শিক্ষার্থী, হাজিরার ইতিহাস, পরীক্ষা ও নোটিশ নিজে থেকেই আপডেট হবে।','Your account and logout':'আপনার অ্যাকাউন্ট ও লগআউট','Your attendance is below 75% this month. Try not to miss classes.':'এই মাসে আপনার উপস্থিতি ৭৫% এর নিচে। ক্লাস মিস না করার চেষ্টা করুন।',
'Your phone opens the chosen app with the message ready. Tap send there, then come back and tap “Send to next”. Sent students are greyed out.':'আপনার ফোনে বাছাই করা অ্যাপ বার্তা সহ খুলবে। সেখানে পাঠান চাপুন, তারপর ফিরে এসে “পরের জনকে পাঠান” চাপুন। যাদের পাঠানো হয়েছে তারা ধূসর হয়ে যাবে।',
'absent':'অনুপস্থিত','present':'উপস্থিত','late':'দেরি','old':'পুরাতন','student':'শিক্ষার্থী','students':'শিক্ষার্থী','none':'নেই','and':'এবং','of':'এর','to':'থেকে',
'bKash':'বিকাশ','B':'B','A':'A','C':'C','D':'D','F':'F','A+':'A+','A-':'A-',
'Sun':'রবি','Mon':'সোম','Tue':'মঙ্গল','Wed':'বুধ','Thu':'বৃহ.','Fri':'শুক্র','Sat':'শনি',
'SMS':'এসএমএস','Edit course':'কোর্স সম্পাদনা','New course':'নতুন কোর্স','Delete course':'কোর্স মুছুন','Account active ':'অ্যাকাউন্ট সক্রিয়',
'Add another link ':'আরেকটি লিংক যোগ করুন','Account':'অ্যাকাউন্ট','Cancel reminder':'রিমাইন্ডার বাতিল','Certificates · ':'সার্টিফিকেট · ','Enter grades / results':'গ্রেড / ফলাফল দিন','Enter marks / results':'নম্বর / ফলাফল দিন',
'Dues list':'বাকির তালিকা','Edit exam details':'পরীক্ষার তথ্য সম্পাদনা','Exam details':'পরীক্ষার তথ্য','Hand over certificate':'সার্টিফিকেট হস্তান্তর','Hand over anyway':'তবুও হস্তান্তর করুন','Lost':'হারানো',
'Language':'ভাষা','English':'English','Bengali numerals':'বাংলা সংখ্যা','Upcoming exam':'আসন্ন পরীক্ষা','Upcoming exams':'আসন্ন পরীক্ষা','Result awaited':'ফল অপেক্ষমাণ','Latest grade':'সর্বশেষ গ্রেড','Pinned':'পিন করা','Pinned notices':'পিন করা নোটিশ','Show more':'আরও দেখুন','Show less':'কম দেখুন','Present today ':'আজ উপস্থিত','Class days':'ক্লাসের দিন','Class day':'ক্লাসের দিন','All time ':'মোট','Exams ':'পরীক্ষা','Show':'দেখুন','Log out ':'লগ আউট',
'Not started':'শুরু হয়নি','Students ':'শিক্ষার্থী','Late arrivals':'দেরিতে আসা','Quick':'দ্রুত','Total':'মোট','Name ':'নাম','Total due':'মোট বাকি','Total due (all months)':'মোট বাকি (সব মাস)','No dues ':'কোনো বাকি নেই','Pass ':'উত্তীর্ণ',
'Sent (phone notification is not set up yet: see Settings)':'পাঠানো হয়েছে (ফোন নোটিফিকেশন এখনও চালু করা হয়নি: সেটিংস দেখুন)',
'Loading…':'লোড হচ্ছে…','Search ':'খুঁজুন','Reports ':'রিপোর্ট','Month ':'মাস','Current':'বর্তমান','Overall':'সামগ্রিক','Notify ':'জানান','Option':'বিকল্প',
});

/* ===== patterns (text with data in it) ===== */
const n=bnNum;
const cnt=(en,bnw)=>pat(new RegExp('^'+en+' \\((\\d+)\\)$'),m=>`${bnw} (${m[1]})`);
[['Active','সক্রিয়'],['Old','পুরাতন'],['All','সব'],['Present','উপস্থিত'],['Late','দেরি'],['Absent','অনুপস্থিত'],['Certificates','সার্টিফিকেট'],['Students','শিক্ষার্থী']].forEach(([a,b])=>cnt(a,b));
pat(/^(\d+) ?\/ ?(\d+) present$/,m=>`${m[1]} / ${m[2]} উপস্থিত`);
pat(/^(\d+) on time$/,m=>`${m[1]} সময়মতো`);pat(/^(\d+) late$/,m=>`${m[1]} দেরি`);pat(/^(\d+) absent$/,m=>`${m[1]} অনুপস্থিত`);
pat(/^late after (\d+) min$/,m=>`${m[1]} মিনিট পর দেরি ধরা হয়`);
pat(/^(\d+) active students?$/,m=>`${m[1]} জন সক্রিয় শিক্ষার্থী`);
pat(/^(\d+) students?$/,m=>`${m[1]} জন শিক্ষার্থী`);pat(/^(\d+) selected$/,m=>`${m[1]} জন বাছাই করা`);
pat(/^(\d+) (?:given|collected)$/,m=>`${m[1]} জন নিয়েছে`);pat(/^(\d+)\/(\d+) given$/,m=>`${m[1]}/${m[2]} জন নিয়েছে`);
pat(/^Results (\d+)\/(\d+)$/,m=>`ফলাফল ${m[1]}/${m[2]}`);pat(/^Certificates (\d+)\/(\d+)$/,m=>`সার্টিফিকেট ${m[1]}/${m[2]}`);
pat(/^ID (.+)$/,m=>`আইডি ${m[1]}`);pat(/^Grade (.+)$/,m=>`গ্রেড ${m[1]}`);
pat(/^Applies to: all batches$/,()=>'প্রযোজ্য: সব ব্যাচ');pat(/^Applies to: (.+)$/,m=>`প্রযোজ্য: ${m[1]}`);
pat(/^due (৳.+)$/,m=>`বাকি ${m[1]}`);pat(/^Due: (৳.+)$/,m=>`বাকি: ${m[1]}`);pat(/^(৳[\d,]+) of (৳[\d,]+)$/,m=>`${m[1]} / ${m[2]}`);
pat(/^Class average (.+)$/,m=>`ক্লাসের গড় ${m[1]}`);pat(/^Highest (.+)$/,m=>`সর্বোচ্চ ${m[1]}`);
pat(/^(\d+)(?:st|nd|rd|th) of (\d+)$/,m=>`${m[2]} জনের মধ্যে ${m[1]} তম`);
pat(/^App v(.+)$/,m=>`অ্যাপ সংস্করণ ${m[1]}`);pat(/^Version (.+)$/,m=>`সংস্করণ ${m[1]}`);pat(/^you have (.+)$/,m=>`আপনার আছে ${m[1]}`);
pat(/^(\d+) days? left$/,m=>`${m[1]} দিন বাকি`);
pat(/^Collected in (.+)$/,m=>`${m[1]} মাসে আদায়`);pat(/^Saved · (.+)$/,m=>`সংরক্ষিত · ${m[1]}`);
pat(/^Delete (.+)\? Attendance history stays\.$/,m=>`${m[1]} কে মুছবেন? হাজিরার ইতিহাস থাকবে।`);
pat(/^Delete batch (.+)\?$/,m=>`ব্যাচ ${m[1]} মুছবেন?`);pat(/^Delete course “(.+)”\?$/,m=>`“${m[1]}” কোর্স মুছবেন?`);
pat(/^Delete exam “(.+)” with all marks and certificate records\? Students will no longer see it\.$/,m=>`“${m[1]}” পরীক্ষা সব নম্বর ও সার্টিফিকেটের রেকর্ড সহ মুছবেন? শিক্ষার্থীরা আর এটি দেখতে পাবে না।`);
pat(/^Remove (.+)\? They will not be able to use the app\./,m=>`${m[1]} কে সরাবেন? তিনি আর অ্যাপ ব্যবহার করতে পারবেন না।`);
pat(/^Rename “(.+)” to “(.+)”\? (\d+) students? and (\d+) other records will be updated\.$/,m=>`“${m[1]}” কে “${m[2]}” নামে বদলাবেন? ${m[3]} জন শিক্ষার্থী ও ${m[4]}টি অন্য রেকর্ড আপডেট হবে।`);
pat(/^Change ID from (.+) to (.+)\? Attendance, fees and results will be moved too\.$/,m=>`আইডি ${m[1]} থেকে ${m[2]} করবেন? হাজিরা, ফি ও ফলাফলও সরে যাবে।`);
pat(/^Undo attendance for (.+)\?$/,m=>`${m[1]} এর হাজিরা ফিরিয়ে নেবেন?`);pat(/^Undone: (.+)$/,m=>`ফিরিয়ে নেওয়া হয়েছে: ${m[1]}`);
pat(/^Move (\d+) students?$/,m=>`${m[1]} জনকে সরান`);pat(/^Reactivate (\d+) old students$/,m=>`${m[1]} জন পুরাতন শিক্ষার্থীকে সক্রিয় করুন`);
pat(/^Finish course: mark all (\d+) as Old$/,m=>`কোর্স শেষ: ${m[1]} জনকেই পুরাতন করুন`);
pat(/^(.+) · students$/,m=>`${m[1]} · শিক্ষার্থী`);pat(/^(.+) \((\d+) students?\)\?$/,m=>`${tx(m[1])} (${m[2]} জন শিক্ষার্থী)?`);
pat(/^Mark all students of (.+) as Old$/,m=>`${m[1]} এর সব শিক্ষার্থীকে পুরাতন করুন`);pat(/^Reactivate old students of (.+)$/,m=>`${m[1]} এর পুরাতন শিক্ষার্থীদের সক্রিয় করুন`);
pat(/^Move all active students from (.+) to (.+)$/,m=>`${m[1]} এর সব সক্রিয় শিক্ষার্থীকে ${m[2]} এ সরান`);
pat(/^(\d+) students? (?:is|are) in this batch\. Move them to another batch first\.$/,m=>`এই ব্যাচে ${m[1]} জন শিক্ষার্থী আছে। আগে তাদের অন্য ব্যাচে সরান।`);
pat(/^Saved (\d+) days?$/,m=>`${m[1]} দিন সংরক্ষিত`);pat(/^Saved (\d+) days?\. Students notified$/,m=>`${m[1]} দিন সংরক্ষিত। শিক্ষার্থীদের জানানো হয়েছে`);
pat(/^Saved (\d+) days?\. Notification scheduled for (.+)$/,m=>`${m[1]} দিন সংরক্ষিত। নোটিফিকেশন নির্ধারিত: ${m[2]}`);
pat(/^Saved\. Reminder scheduled for (.+)$/,m=>`সংরক্ষিত। রিমাইন্ডার নির্ধারিত: ${m[1]}`);
pat(/^Saved, but (.+)$/,m=>`সংরক্ষিত, কিন্তু ${m[1]}`);pat(/^Uploaded (\d+) offline attendance records?$/,m=>`${m[1]}টি অফলাইন হাজিরা আপলোড হয়েছে`);
pat(/^Uploaded (\d+)(.*)$/,m=>`${m[1]}টি আপলোড হয়েছে${m[2]}`);
pat(/^(\d+) offline attendance records? (?:is|are) not uploaded yet\./,m=>`${m[1]}টি অফলাইন হাজিরা এখনও আপলোড হয়নি।`);pat(/^(\d+) waiting to upload\.$/,m=>`${m[1]}টি আপলোডের অপেক্ষায়।`);
pat(/^Uploading (\d+)\/(\d+)…$/,m=>`আপলোড হচ্ছে ${m[1]}/${m[2]}…`);pat(/^Moving (\d+)\/(\d+)…$/,m=>`সরানো হচ্ছে ${m[1]}/${m[2]}…`);pat(/^Updating (\d+)\/(\d+)…$/,m=>`আপডেট হচ্ছে ${m[1]}/${m[2]}…`);pat(/^Saving (\d+)\/(\d+)…$/,m=>`সংরক্ষণ হচ্ছে ${m[1]}/${m[2]}…`);
pat(/^Downloading… (\d+)%(.*)$/,m=>`ডাউনলোড হচ্ছে… ${m[1]}%${m[2]}`);
pat(/^(.+) marked present$/,m=>`${m[1]} উপস্থিত`);pat(/^(.+) marked late$/,m=>`${m[1]} দেরিতে উপস্থিত`);
pat(/^(.+) marked present \(saved offline\)(.*)$/,m=>`${m[1]} উপস্থিত (অফলাইনে সংরক্ষিত)${m[2]}`);pat(/^(.+) marked late \(saved offline\)(.*)$/,m=>`${m[1]} দেরিতে উপস্থিত (অফলাইনে সংরক্ষিত)${m[2]}`);
pat(/^(.+) is already marked(?: \((.+)\))?$/,m=>`${m[1]} এর হাজিরা আগেই হয়েছে${m[2]?` (${m[2]})`:''}`);
pat(/^(.+) has completed the course \(old student\)$/,m=>`${m[1]} কোর্স শেষ করেছেন (পুরাতন শিক্ষার্থী)`);
pat(/^(.+) is in (.+), which is not one of your batches$/,m=>`${m[1]} ${m[2]} ব্যাচে, যা আপনার ব্যাচ নয়`);
pat(/^(.+): (.+) runs (.+)–(.+)$/,m=>`${m[1]}: ${m[2]} এর সময় ${m[3]}–${m[4]}`);
pat(/^Batch "(.+)" not found/,m=>`ব্যাচ "${m[1]}" পাওয়া যায়নি`);
pat(/^QR is (\d+) min old\..*$/,m=>`QR ${m[1]} মিনিট আগের। শিক্ষার্থীকে বর্তমান QR দেখাতে বলুন। বারবার হলে ফোনের তারিখ ও সময় অটোমেটিক করুন।`);
pat(/^The student's phone clock is (\d+) min ahead\..*$/,m=>`শিক্ষার্থীর ফোনের ঘড়ি ${m[1]} মিনিট এগিয়ে আছে। তারিখ ও সময় অটোমেটিক করুন।`);
pat(/^Android needs your permission/,()=>BN['Android needs your permission to install updates from this app. Tap “Allow”, switch on “Allow from this source”, then come back here.']);
pat(/^Version (.+) · you have (.+) · (.+) MB$/,m=>`সংস্করণ ${m[1]} · আপনার ${m[2]} · ${m[3]} এমবি`);
pat(/^You are on the latest version \(v(.+)\)$/,m=>`আপনি সর্বশেষ সংস্করণে আছেন (v${m[1]})`);
pat(/^(.+) is not on the staff list, the account is disabled/,m=>`${m[1]} স্টাফ তালিকায় নেই, অথবা অ্যাকাউন্ট বন্ধ, অথবা প্রথম সাইন-ইনের জন্য ইন্টারনেট নেই। মালিককে যোগ বা চালু করতে বলুন।`);
pat(/^This is ৳(.+) more than the due amount\. Save anyway\?$/,m=>`এটি বাকির চেয়ে ৳${m[1]} বেশি। তবুও সংরক্ষণ করবেন?`);
pat(/^Transaction ID (.+) was already used for another payment\. Save anyway\?$/,m=>`ট্রানজেকশন আইডি ${m[1]} আগে অন্য পেমেন্টে ব্যবহার হয়েছে। তবুও সংরক্ষণ করবেন?`);
pat(/^Void receipt (.+)\? It will stay/,m=>`রসিদ ${m[1]} বাতিল করবেন? এটি ইতিহাসে “বাতিল” হিসেবে থাকবে এবং হিসাবে ধরা হবে না।`);
pat(/^You have (৳.+) due for the course fee\. Please pay at the office\.$/,m=>`কোর্স ফি বাবদ আপনার ${m[1]} বাকি আছে। অনুগ্রহ করে অফিসে পরিশোধ করুন।`);
pat(/^You have (৳.+) due for (\d+) months?\. Please pay at the office\.$/,m=>`${m[2]} মাসের ${m[1]} বাকি আছে। অনুগ্রহ করে অফিসে পরিশোধ করুন।`);
pat(/^Certificates · (\d+) given of (\d+) who passed$/,m=>`সার্টিফিকেট · উত্তীর্ণ ${m[2]} জনের মধ্যে ${m[1]} জন পেয়েছে`);
pat(/^Mark certificates as arrived and notify (\d+) students\?$/,m=>`সার্টিফিকেট এসেছে চিহ্নিত করে ${m[1]} জন শিক্ষার্থীকে জানাবেন?`);
pat(/^Move (\d+) students? who received the certificate to Old students\?$/,m=>`সার্টিফিকেট পাওয়া ${m[1]} জনকে পুরাতন শিক্ষার্থীতে সরাবেন?`);
pat(/^Goes to the (\d+) students? of this exam, right now\.$/,m=>`এই পরীক্ষার ${m[1]} জন শিক্ষার্থীকে এখনই যাবে।`);
pat(/^Hand over anyway \(due (৳.+) stays\)$/,m=>`তবুও হস্তান্তর করুন (${m[1]} বাকি থাকবে)`);
pat(/^\(paid (৳.+) of (৳.+)\)\. Collect the due before giving the certificate\.$/,m=>`(${m[2]} এর মধ্যে ${m[1]} পরিশোধিত)। সার্টিফিকেট দেওয়ার আগে বাকি টাকা নিন।`);
pat(/^Delete (.+) \(student\)$/,m=>m[1]);
pat(/^(\d+) selected$/,m=>`${m[1]} জন বাছাই করা`);
pat(/^(.+) · ID$/,m=>`${m[1]} · আইডি`);
pat(/^(\d+)\s*(?:min|minutes)$/,m=>`${m[1]} মিনিট`);
pat(/^Rename (.+)$/,m=>`নাম বদলান ${m[1]}`);
pat(/^No number for (.+)$/,m=>`${m[1]} এর কোনো নম্বর নেই`);
pat(/^(\d+) of (\d+) sent$/,m=>`${m[2]} জনের মধ্যে ${m[1]} জনকে পাঠানো হয়েছে`);
pat(/^(\d+) batch(?:es)? (?:use|uses) this course\. Change them first\.$/,m=>`${m[1]}টি ব্যাচ এই কোর্স ব্যবহার করছে। আগে সেগুলো বদলান।`);
pat(/^Sent to (\d+)$/,m=>`${m[1]} জনকে পাঠানো হয়েছে`);
pat(/^Added (\d+)(.*)$/,m=>`${m[1]} জন যোগ হয়েছে${m[2]?m[2].replace(', skipped',', বাদ'):''}`);
pat(/^Done: (\d+) (.+)$/,m=>`হয়েছে: ${m[1]} ${m[2]}`);
pat(/^Camera error/,()=>BN['Camera error: allow camera permission and reopen this tab']);
pat(/^Error: (.+)$/,m=>`ত্রুটি: ${m[1]}`);

/* ===== dictionary: additions found by the coverage audit ===== */
add({
', otherwise the phone may block notices when the app is closed.':', না হলে অ্যাপ বন্ধ থাকলে ফোন নোটিশ আটকে দিতে পারে।',
'1 day before, 6:00 PM':'১ দিন আগে, বিকাল ৬:০০','2 days before, 6:00 PM':'২ দিন আগে, বিকাল ৬:০০','Exam day, 7:00 AM ':'পরীক্ষার দিন, সকাল ৭:০০',
'Administrator':'প্রশাসক','Class time':'ক্লাসের সময়','Course, Blood group':'কোর্স, রক্তের গ্রুপ','Cover image':'কভার ছবি','Replace cover image':'কভার ছবি বদলান','Remove cover image':'কভার ছবি সরান',
'Torch':'টর্চ','Light':'লাইট','Dark':'ডার্ক','System':'সিস্টেম','Owner':'মালিক','Teacher':'শিক্ষক','Owner (full access)':'মালিক (সব অধিকার)','You':'আপনি','Co-owner':'সহ-মালিক',
'Exam done, certificate not arrived yet':'পরীক্ষা শেষ, সার্টিফিকেট এখনও আসেনি','the grade is calculated':'গ্রেড নিজে হিসাব হবে','Import list':'তালিকা ইমপোর্ট','Login list (PDF)':'লগইন তালিকা (পিডিএফ)','Mark Active':'সক্রিয় করুন','Mark Old':'পুরাতন করুন','Move to batch…':'ব্যাচে সরান…',
'No batches yet. Create one in More → Batches.':'এখনও কোনো ব্যাচ নেই। আরও → ব্যাচ এ গিয়ে তৈরি করুন।','Not marked':'হাজিরা হয়নি','No result yet':'এখনও ফল নেই','Please pay':'অনুগ্রহ করে পরিশোধ করুন',
'Owners can do everything. Teachers can only take attendance and see students of the batches you give them. They cannot see passwords, fees, exams or settings.':'মালিক সবকিছু করতে পারেন। শিক্ষকরা শুধু হাজিরা নিতে এবং আপনার দেওয়া ব্যাচের শিক্ষার্থী দেখতে পারেন। তারা পাসওয়ার্ড, ফি, পরীক্ষা বা সেটিংস দেখতে পারেন না।',
'Save as default':'ডিফল্ট হিসেবে সংরক্ষণ','Save name':'নাম সংরক্ষণ','Your display name':'আপনার প্রদর্শনের নাম',
'Sent automatically by the notification server (Cloudflare cron). “Send now” sends it immediately.':'নোটিফিকেশন সার্ভার (Cloudflare cron) নিজে থেকে পাঠায়। “এখনই পাঠান” চাপলে সঙ্গে সঙ্গে যাবে।',
'Student ID is the user ID. The student’s mobile number is the password. Download one PDF with photos, or copy / share one student’s login.':'স্টুডেন্ট আইডি হলো ইউজার আইডি, শিক্ষার্থীর মোবাইল নম্বর হলো পাসওয়ার্ড। ছবি সহ একটি পিডিএফ ডাউনলোড করুন, অথবা একজনের লগইন কপি / শেয়ার করুন।',
'The preset must be':'প্রিসেট অবশ্যই','Unsigned':'Unsigned','in Cloudinary → Settings → Upload. To let students open PDFs, also enable “Allow delivery of PDF and ZIP files” in Cloudinary → Settings → Security.':'Cloudinary → Settings → Upload এ থাকতে হবে। শিক্ষার্থীরা পিডিএফ খুলতে পারার জন্য Cloudinary → Settings → Security তে “Allow delivery of PDF and ZIP files” ও চালু করুন।',
'Use {name} {batch} {date} {time} {due} {months} {inst}':'ব্যবহার করুন {name} {batch} {date} {time} {due} {months} {inst}',
'e.g. 8N4K2L9X':'যেমন 8N4K2L9X','e.g. Advanced Excel':'যেমন অ্যাডভান্সড এক্সেল','e.g. Eid-ul-Fitr':'যেমন ঈদুল ফিতর','e.g. Fees are not refundable.':'যেমন ফি ফেরতযোগ্য নয়।','e.g. Final exam':'যেমন ফাইনাল পরীক্ষা','e.g. Room 2 / BTEB exam center':'যেমন ২ নং কক্ষ / বিটিইবি পরীক্ষা কেন্দ্র','e.g. Monthly test 1':'যেমন মাসিক পরীক্ষা ১','e.g. 500':'যেমন ৫০০','Leave empty to use the standard message ':'খালি রাখলে সাধারণ বার্তা যাবে',
'empty = use the course fee':'খালি = কোর্সের ফি ব্যবহার হবে','empty = course / batch fee':'খালি = কোর্স / ব্যাচের ফি','empty = use the course fee ':'খালি = কোর্সের ফি','below 75% this month':'এই মাসে ৭৫% এর নিচে','leave empty to use the batch fee':'খালি রাখলে ব্যাচের ফি ব্যবহার হবে',
'· Password':'· পাসওয়ার্ড','— none (monthly fee) —':'— কিছু নয় (মাসিক ফি) —','— none —':'— কিছু নয় —','⏰ Scheduled notifications':'⏰ নির্ধারিত নোটিফিকেশন','🌐 Online.':'🌐 অনলাইন।','🎉 Event':'🎉 অনুষ্ঠান','🎓 Hand over certificate':'🎓 সার্টিফিকেট হস্তান্তর','🏖️ Holiday':'🏖️ ছুটি','💳 Fee':'💳 ফি','📝 Exam':'📝 পরীক্ষা','📢 Notice':'📢 নোটিশ','🚨 Important':'🚨 গুরুত্বপূর্ণ',
'Institute exam':'প্রতিষ্ঠানের পরীক্ষা','Board exam (results come from the board)':'বোর্ড পরীক্ষা (ফল বোর্ড থেকে আসে)','Board exam':'বোর্ড পরীক্ষা','course fee':'কোর্স ফি','No weekly off ':'সাপ্তাহিক ছুটি নেই',
'Fri':'শুক্র','Mon':'সোম','Tue':'মঙ্গল','Wed':'বুধ','Thu':'বৃহ.','Sat':'শনি','Sun':'রবি',
'Student ID or mobile number':'স্টুডেন্ট আইডি বা মোবাইল','Hand over anyway':'তবুও হস্তান্তর করুন','Move this student to Old students ':'এই শিক্ষার্থীকে পুরাতনে সরান',
'Student himself':'শিক্ষার্থী নিজে','Guardian ':'অভিভাবক','Mark certificates as arrived':'সার্টিফিকেট এসেছে চিহ্নিত করুন','Certificates arrived: notify everyone':'সার্টিফিকেট এসেছে: সবাইকে জানান',
'🎓 Certificates arrived: notify everyone':'🎓 সার্টিফিকেট এসেছে: সবাইকে জানান','Hand over':'হস্তান্তর করুন','Given':'দেওয়া হয়েছে','Report by':'আসার সময়',
});
pat(/^(\d+) new notices?$/,m=>`${m[1]}টি নতুন নোটিশ`);pat(/^(\d+) active$/,m=>`${m[1]} জন সক্রিয়`);pat(/^(\d+) old$/,m=>`${m[1]} জন পুরাতন`);
pat(/^Full marks (\d+)$/,m=>`পূর্ণমান ${m[1]}`);pat(/^pass (\d+)$/,m=>`পাস ${m[1]}`);pat(/^Holiday: (.+)$/,m=>`ছুটি: ${m[1]}`);
pat(/^✅ No dues\. Paid (৳.+)\.$/,m=>`✅ কোনো বাকি নেই। পরিশোধ ${m[1]}।`);pat(/^🎓 Certificates arrived on (.+)\.$/,m=>`🎓 সার্টিফিকেট এসেছে ${m[1]}।`);pat(/^arrived (.+)$/,m=>`এসেছে ${m[1]}`);
pat(/^(\d+) given of (\d+) who passed$/,m=>`উত্তীর্ণ ${m[2]} জনের মধ্যে ${m[1]} জন পেয়েছে`);pat(/^(\d+)\/(\d+) days$/,m=>`${m[1]}/${m[2]} দিন`);
pat(/^(৳.+) course fee$/,m=>`${m[1]} কোর্স ফি`);pat(/^(৳.+) per month$/,m=>`${m[1]} প্রতি মাসে`);pat(/^(.+) \(board exam\)$/,m=>`${m[1]} (বোর্ড পরীক্ষা)`);pat(/^(.+) \(institute exam\)$/,m=>`${m[1]} (প্রতিষ্ঠানের পরীক্ষা)`);
const DAYS={Sun:'রবি',Mon:'সোম',Tue:'মঙ্গল',Wed:'বুধ',Thu:'বৃহ.',Fri:'শুক্র',Sat:'শনি'};
pat(/^Off: (.+)$/,m=>`ছুটি: ${m[1].replace(/\b(Sun|Mon|Tue|Wed|Thu|Fri|Sat)\b/g,d=>DAYS[d])}`);pat(/^counting from (.+)$/,m=>`গণনা শুরু ${m[1]}`);pat(/^Fee (৳.+)$/,m=>`ফি ${m[1]}`);
pat(/^(\d+) (?:AM|PM)$/,m=>m[0]);
add({'New student':'নতুন শিক্ষার্থী','Edit student':'শিক্ষার্থী সম্পাদনা','Delete student':'শিক্ষার্থী মুছুন','🎓 arrived':'🎓 এসেছে','🎓 Certificates':'🎓 সার্টিফিকেট'});
pat(/^🎓 collected (.+)$/,m=>`🎓 নিয়েছে ${m[1]}`);pat(/^(\d+) \((student|guardian)\)$/,m=>`${m[1]} (${m[2]==='student'?'শিক্ষার্থী':'অভিভাবক'})`);
add({
'Class days are days with attendance plus scheduled days (not a weekly off, not a holiday). Students are counted only between their joined and left dates.':'ক্লাসের দিন মানে যেদিন হাজিরা হয়েছে এবং নির্ধারিত দিন (সাপ্তাহিক ছুটি বা ছুটি নয়)। শিক্ষার্থীকে শুধু ভর্তি ও ছাড়ার তারিখের মধ্যে গণনা করা হয়।',
'Tap “Install” in the Android window. The app restarts when it is done. If nothing appeared, tap the button below.':'অ্যান্ড্রয়েডের উইন্ডোতে “ইনস্টল” চাপুন। শেষ হলে অ্যাপ আবার চালু হবে। কিছু না এলে নিচের বাটন চাপুন।',
'“To” date is before “From”':'“পর্যন্ত” তারিখ “থেকে” তারিখের আগে','Image error':'ছবির ত্রুটি','A course with this name already exists':'এই নামে কোর্স আগে থেকেই আছে','⏰ reminder':'⏰ রিমাইন্ডার','Cloudinary:':'Cloudinary:',
});
pat(/^Reset email sent to (.+)$/,m=>`${m[1]} এ রিসেট ইমেইল পাঠানো হয়েছে`);
add({'Attendance marked!':'হাজিরা সম্পন্ন!','Marked late':'দেরিতে উপস্থিত','You are present':'আপনি উপস্থিত','You are present today':'আজ আপনি উপস্থিত','You arrived late today':'আজ আপনি দেরিতে এসেছেন','marked by admin':'অ্যাডমিন চিহ্নিত করেছেন','backup code':'ব্যাকআপ কোড','QR scan':'QR স্ক্যান','Code':'কোড','Manual ':'ম্যানুয়াল','Notices ':'নোটিশ','Present at':'উপস্থিত','Load more':'আরও দেখুন','Student app login':'স্টুডেন্ট অ্যাপ লগইন','Name:':'নাম:'});
add({
'All courses':'সব কোর্স','No course':'কোর্স নেই','— no course —':'— কোর্স নেই —','— choose —':'— বেছে নিন —','Set course…':'কোর্স ঠিক করুন…',
'Course':'কোর্স','the course this student enrolled in':'শিক্ষার্থী যে কোর্সে ভর্তি','empty = fee of the course':'খালি = কোর্সের ফি','Monthly fee (৳)':'মাসিক ফি (৳)','only for students who have no course':'শুধু যাদের কোনো কোর্স নেই তাদের জন্য',
'Students are taken from this course, whatever their batch.':'এই কোর্সের শিক্ষার্থীদের নেওয়া হবে, তাদের ব্যাচ যেটাই হোক।','Choose the course above to see its students.':'শিক্ষার্থী দেখতে উপরে কোর্স বেছে নিন।','No student is enrolled in this course yet. Set the course in Students → Edit.':'এই কোর্সে এখনও কেউ ভর্তি নেই। শিক্ষার্থী → সম্পাদনা থেকে কোর্স ঠিক করুন।',
'Choose the course':'কোর্স বেছে নিন','Add a course first (Settings → Courses)':'আগে একটি কোর্স যোগ করুন (সেটিংস → কোর্স)',
'Choose the course when you add or edit a student. Students of the same batch can be in different courses. The fee here is used for each student of that course, unless you set a different fee for that student.':'শিক্ষার্থী যোগ বা সম্পাদনার সময় কোর্স বেছে নিন। একই ব্যাচের শিক্ষার্থীরা আলাদা কোর্সে থাকতে পারে। শিক্ষার্থীর আলাদা ফি না দিলে এখানকার ফি ওই কোর্সের প্রত্যেকের জন্য ধরা হবে।',
'Older versions kept the course on the batch. Copy it to students who have no course yet (one time).':'আগের সংস্করণে কোর্স ব্যাচে থাকত। যাদের এখনও কোর্স নেই তাদের কাছে কপি করুন (একবার)।','Copy batch course to students':'ব্যাচের কোর্স শিক্ষার্থীদের কাছে কপি করুন',
'ID, Name, Mobile, Batch, Course':'আইডি, নাম, মোবাইল, ব্যাচ, কোর্স','(course is optional)':'(কোর্স ঐচ্ছিক)','Monthly fee':'মাসিক ফি',
});
pat(/^Set course for (\d+) students?$/,m=>`${m[1]} জনের কোর্স ঠিক করুন`);pat(/^(\d+) students? (?:are|is) in this course\. Change them first\.$/,m=>`${m[1]} জন শিক্ষার্থী এই কোর্সে আছে। আগে তাদের বদলান।`);pat(/^Monthly fee (৳.+)$/,m=>`মাসিক ফি ${m[1]}`);
